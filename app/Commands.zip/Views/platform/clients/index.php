<?= $this->extend('layouts/platform') ?>

<?= $this->section('content') ?>
<div class="platform-fleet">
<?php
$totals  = $totals ?? [];
$clients = $clients ?? [];
$fmt = static function ($n): string {
    return number_format((int) $n);
};
?>

<section class="platform-kpi-grid">
    <div class="platform-kpi">
        <div class="platform-kpi-label">Clients</div>
        <div class="platform-kpi-value"><?= $fmt($totals['clients'] ?? 0) ?></div>
        <div class="platform-kpi-hint"><?= $fmt($totals['online'] ?? 0) ?> healthy · <?= $fmt($totals['warn'] ?? 0) ?> setup</div>
    </div>
    <div class="platform-kpi">
        <div class="platform-kpi-label">Contacts</div>
        <div class="platform-kpi-value"><?= $fmt($totals['contacts'] ?? 0) ?></div>
        <div class="platform-kpi-hint">Across all workspaces</div>
    </div>
    <div class="platform-kpi">
        <div class="platform-kpi-label">WhatsApp sent</div>
        <div class="platform-kpi-value"><?= $fmt($totals['sent'] ?? 0) ?></div>
        <div class="platform-kpi-hint">Delivery <?= esc((string) ($totals['delivery_rate'] ?? 0)) ?>%</div>
    </div>
    <div class="platform-kpi">
        <div class="platform-kpi-label">Failed</div>
        <div class="platform-kpi-value"><?= $fmt($totals['failed'] ?? 0) ?></div>
        <div class="platform-kpi-hint">Fail rate <?= esc((string) ($totals['fail_rate'] ?? 0)) ?>%</div>
    </div>
    <div class="platform-kpi">
        <div class="platform-kpi-label">Open chats</div>
        <div class="platform-kpi-value"><?= $fmt($totals['open_chats'] ?? 0) ?></div>
        <div class="platform-kpi-hint">Queue <?= $fmt($totals['queue'] ?? 0) ?> pending</div>
    </div>
    <div class="platform-kpi">
        <div class="platform-kpi-label">Meta ready</div>
        <div class="platform-kpi-value"><?= $fmt($totals['meta_ready'] ?? 0) ?>/<?= $fmt($totals['clients'] ?? 0) ?></div>
        <div class="platform-kpi-hint">WhatsApp connected</div>
    </div>
</section>

<div class="platform-section-label">
    <h2>Email</h2>
    <p>Recipient-level email performance across every workspace</p>
</div>

<section class="platform-kpi-grid">
    <div class="platform-kpi">
        <div class="platform-kpi-label">Emails sent</div>
        <div class="platform-kpi-value"><?= $fmt($totals['email_sent'] ?? 0) ?></div>
        <div class="platform-kpi-hint"><?= $fmt($totals['email_failed'] ?? 0) ?> failed</div>
    </div>
    <div class="platform-kpi">
        <div class="platform-kpi-label">Opens</div>
        <div class="platform-kpi-value"><?= $fmt($totals['email_opened'] ?? 0) ?></div>
        <div class="platform-kpi-hint">Open rate <?= esc((string) ($totals['email_open_rate'] ?? 0)) ?>%</div>
    </div>
    <div class="platform-kpi">
        <div class="platform-kpi-label">Clicks</div>
        <div class="platform-kpi-value"><?= $fmt($totals['email_clicked'] ?? 0) ?></div>
        <div class="platform-kpi-hint">Tracked link clicks</div>
    </div>
    <div class="platform-kpi">
        <div class="platform-kpi-label">Bounces</div>
        <div class="platform-kpi-value"><?= $fmt($totals['email_bounced'] ?? 0) ?></div>
        <div class="platform-kpi-hint">Bounce rate <?= esc((string) ($totals['email_bounce_rate'] ?? 0)) ?>%</div>
    </div>
    <div class="platform-kpi">
        <div class="platform-kpi-label">Unsubscribed</div>
        <div class="platform-kpi-value"><?= $fmt($totals['email_unsubscribed'] ?? 0) ?></div>
        <div class="platform-kpi-hint">Active opt-outs</div>
    </div>
    <div class="platform-kpi">
        <div class="platform-kpi-label">Email ready</div>
        <div class="platform-kpi-value"><?= $fmt($totals['email_ready'] ?? 0) ?>/<?= $fmt($totals['clients'] ?? 0) ?></div>
        <div class="platform-kpi-hint">Provider + sender set</div>
    </div>
</section>

<div class="platform-section-label">
    <h2>Analytics</h2>
    <p>Live performance across every client workspace</p>
</div>

<section class="platform-charts-grid">
    <article class="platform-card platform-chart-card">
        <div class="platform-card-head">
            <div>
                <h2>Message trends</h2>
                <p>Sent · delivered · failed · replies · 14 days</p>
            </div>
        </div>
        <div class="platform-chart-wrap is-lg">
            <canvas id="pfTrendChart" aria-label="Message trends chart"></canvas>
        </div>
    </article>
    <article class="platform-card platform-chart-card">
        <div class="platform-card-head">
            <div>
                <h2>Fleet health</h2>
                <p>Healthy · setup needed · offline</p>
            </div>
        </div>
        <div class="platform-chart-wrap">
            <canvas id="pfHealthChart" aria-label="Fleet health chart"></canvas>
        </div>
    </article>
</section>

<section class="platform-charts-grid">
    <article class="platform-card platform-chart-card">
        <div class="platform-card-head">
            <div>
                <h2>Contacts by client</h2>
                <p>Audience size vs WhatsApp and email sent</p>
            </div>
        </div>
        <div class="platform-chart-wrap">
            <canvas id="pfContactsChart" aria-label="Contacts by client chart"></canvas>
        </div>
    </article>
    <article class="platform-card platform-chart-card">
        <div class="platform-card-head">
            <div>
                <h2>Delivery mix</h2>
                <p>Delivered vs failed vs other</p>
            </div>
        </div>
        <div class="platform-chart-wrap">
            <canvas id="pfDeliveryChart" aria-label="Delivery mix chart"></canvas>
        </div>
    </article>
</section>

</div>
<?= $this->endSection() ?>

<?= $this->section('scripts') ?>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.2/dist/chart.umd.min.js"></script>
<script>
(function () {
    var data = <?= $chartsJson ?? '{}' ?>;
    if (!window.Chart || !data || !data.trend) return;

    var teal = '#e11d48';
    var coral = '#c45c12';
    var ink = '#1a2330';
    var mute = '#6b7780';
    var soft = '#6f9b4c';

    Chart.defaults.font.family = "'Figtree', system-ui, sans-serif";
    Chart.defaults.color = mute;
    Chart.defaults.plugins.legend.labels.usePointStyle = true;
    Chart.defaults.plugins.legend.labels.boxWidth = 8;
    Chart.defaults.plugins.legend.labels.padding = 14;

    function lineChart(el, trend) {
        new Chart(el, {
            type: 'line',
            data: {
                labels: trend.labels || [],
                datasets: [
                    { label: 'Sent', data: trend.sent || [], borderColor: teal, backgroundColor: 'rgba(225,29,72,.10)', tension: 0.35, fill: true, borderWidth: 2.5, pointRadius: 2 },
                    { label: 'Delivered', data: trend.delivered || [], borderColor: soft, backgroundColor: 'transparent', tension: 0.35, borderWidth: 2, pointRadius: 2 },
                    { label: 'Failed', data: trend.failed || [], borderColor: coral, backgroundColor: 'transparent', tension: 0.35, borderWidth: 2, pointRadius: 2 },
                    { label: 'Replies', data: trend.replies || [], borderColor: ink, backgroundColor: 'transparent', tension: 0.35, borderWidth: 2, borderDash: [5, 4], pointRadius: 2 }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                interaction: { mode: 'index', intersect: false },
                plugins: { legend: { position: 'bottom' } },
                scales: {
                    x: { grid: { display: false }, ticks: { maxRotation: 0 } },
                    y: { beginAtZero: true, grid: { color: 'rgba(26,35,48,.06)' }, ticks: { precision: 0 } }
                }
            }
        });
    }

    var elTrend = document.getElementById('pfTrendChart');
    if (elTrend) lineChart(elTrend, data.trend || {});

    var health = data.health || {};
    var elHealth = document.getElementById('pfHealthChart');
    if (elHealth) {
        new Chart(elHealth, {
            type: 'doughnut',
            data: {
                labels: health.labels || [],
                datasets: [{ data: health.values || [], backgroundColor: [teal, '#c79200', coral], borderWidth: 0, hoverOffset: 4 }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { position: 'bottom' } },
                cutout: '68%'
            }
        });
    }

    var clients = data.clients || {};
    var elContacts = document.getElementById('pfContactsChart');
    if (elContacts) {
        new Chart(elContacts, {
            type: 'bar',
            data: {
                labels: clients.labels || [],
                datasets: [
                    { label: 'Contacts', data: clients.contacts || [], backgroundColor: teal, borderRadius: 5, maxBarThickness: 28 },
                    { label: 'WhatsApp sent', data: clients.sent || [], backgroundColor: 'rgba(196,92,18,.78)', borderRadius: 5, maxBarThickness: 28 },
                    { label: 'Emails sent', data: clients.email_sent || [], backgroundColor: 'rgba(26,35,48,.7)', borderRadius: 5, maxBarThickness: 28 }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { position: 'bottom' } },
                scales: {
                    x: { grid: { display: false } },
                    y: { beginAtZero: true, grid: { color: 'rgba(26,35,48,.06)' }, ticks: { precision: 0 } }
                }
            }
        });
    }

    var delivery = data.delivery || {};
    var elDelivery = document.getElementById('pfDeliveryChart');
    if (elDelivery) {
        new Chart(elDelivery, {
            type: 'doughnut',
            data: {
                labels: delivery.labels || [],
                datasets: [{ data: delivery.values || [], backgroundColor: [teal, coral, '#c2cdc6'], borderWidth: 0, hoverOffset: 4 }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { position: 'bottom' } },
                cutout: '62%'
            }
        });
    }
})();
</script>
<?= $this->endSection() ?>
