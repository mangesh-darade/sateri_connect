<?= $this->extend('layouts/main') ?>

<?= $this->section('header_actions') ?>
<a href="<?= site_url('emails') ?>" class="btn btn-sm btn-outline-secondary"><i class="fas fa-arrow-left me-1"></i> Back</a>
<?= $this->endSection() ?>

<?= $this->section('content') ?>
<?php
$provider = $provider ?? 'smtp';
$providerLabel = $providerLabel ?? 'SMTP';
$providerDetail = $providerDetail ?? '';
$defaultTo = $defaultTo ?? 'sateri.mangesh@gmail.com';
$defaultCampaign = $defaultCampaign ?? 'app-direct';
$campaigns = $campaigns ?? [];
$emailCampaigns = $emailCampaigns ?? [];
?>
<div class="form-shell form-shell-lg page-stack">
    <div class="card form-card" id="emailSingleCard"
         data-send-url="<?= site_url('emails/send') ?>"
         data-provider="<?= esc($provider) ?>">
        <form id="emailSingleForm" method="post" action="<?= site_url('emails/send') ?>" enctype="multipart/form-data">
            <?= csrf_field() ?>
            <div class="card-body">
                <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
                    <span class="badge text-bg-dark">Send via <?= esc($providerLabel) ?></span>
                </div>
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label" for="emailTo">To <span class="text-danger">*</span></label>
                        <input type="email" class="form-control" id="emailTo" name="to" required
                               value="<?= esc(old('to') ?? $defaultTo) ?>" placeholder="name@example.com">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label" for="emailCampaign">Campaign name <span class="text-muted fw-normal small">(Optional)</span></label>
                        <?php 
                            $selectedSingleCampaign = (string) (old('campaign_name') ?? $defaultCampaign ?? '');
                            $isKnownSingle = $selectedSingleCampaign === '' || $selectedSingleCampaign === 'app-direct' 
                                || in_array($selectedSingleCampaign, array_column($emailCampaigns ?? [], 'name'), true);
                        ?>
                        <select class="form-select" id="emailCampaign" name="campaign_name">
                            <option value="">— Select Campaign (Optional) —</option>
                            <option value="app-direct" <?= ($selectedSingleCampaign === 'app-direct') ? 'selected' : '' ?>>
                                app-direct (Default)
                            </option>
                            <?php if (!empty($emailCampaigns)): ?>
                                <optgroup label="Email Campaigns">
                                    <?php foreach ($emailCampaigns as $ec): ?>
                                        <?php 
                                            $ecName = (string) ($ec['name'] ?? '');
                                            if ($ecName === '' || $ecName === 'app-direct') continue;
                                        ?>
                                        <option value="<?= esc($ecName) ?>" <?= ($selectedSingleCampaign === $ecName) ? 'selected' : '' ?>>
                                            <?= esc($ecName) ?><?= !empty($ec['status']) ? ' (' . esc(ucfirst($ec['status'])) . ')' : '' ?>
                                        </option>
                                    <?php endforeach; ?>
                                </optgroup>
                            <?php endif; ?>
                            <option value="__custom__" <?= (! $isKnownSingle && $selectedSingleCampaign !== '') ? 'selected' : '' ?>>
                                + Enter Custom Campaign...
                            </option>
                        </select>
                        <input type="text" class="form-control mt-1.5 <?= (! $isKnownSingle && $selectedSingleCampaign !== '') ? '' : 'd-none' ?>" 
                               id="emailCampaignCustom" 
                               placeholder="Type custom campaign name..."
                               value="<?= (! $isKnownSingle) ? esc($selectedSingleCampaign) : '' ?>">
                        <div class="form-text">Used as analytics label (External / SendGrid).</div>
                    </div>
                    <div class="col-12">
                        <label class="form-label" for="emailSubject">Subject <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="emailSubject" name="subject" required maxlength="250"
                               value="<?= esc(old('subject') ?? '') ?>" placeholder="Subject line">
                    </div>
                    <div class="col-12">
                        <label class="form-label mb-1" for="emailBody">Message <span class="text-danger">*</span></label>
                        <textarea class="form-control font-monospace" id="emailBody" name="body" rows="10" required data-email-editor data-email-subject="#emailSubject"
                                  placeholder="Write your message…"><?= esc(old('body') ?? '') ?></textarea>
                    </div>
                    <div class="col-12">
                        <label class="form-label" for="emailAttachment">
                            <i class="fas fa-paperclip text-muted me-1"></i> Attach Document / Media 
                            <span class="text-muted fw-normal small">(Optional — PDF, JPG, PNG, WEBP, XLSX, CSV, DOCX — Max 5MB)</span>
                        </label>
                        <div class="input-group">
                            <input type="file" class="form-control" id="emailAttachment" name="attachment" 
                                   accept=".pdf,.jpg,.jpeg,.png,.webp,.xlsx,.csv,.docx">
                            <button class="btn btn-outline-secondary d-none" type="button" id="btnClearSingleAttachment" title="Clear file">
                                <i class="fas fa-times"></i>
                            </button>
                        </div>
                        <div class="form-text text-muted small" id="singleAttachmentInfo">
                            Physical attachment will be safely attached and delivered directly with the email.
                        </div>
                    </div>
                </div>
            </div>
            <div class="card-footer d-flex flex-wrap gap-2">
                <a href="<?= site_url('emails') ?>" class="btn btn-outline-secondary">Cancel</a>
                <button type="submit" class="btn btn-wa" id="btnSendSingle">
                    <i class="fas fa-paper-plane me-1"></i> Send via <?= esc($providerLabel) ?>
                </button>
            </div>
        </form>
        <div id="emailSingleResult" class="px-3 pb-3"></div>
    </div>
</div>
<?= $this->endSection() ?>

<?= $this->section('styles') ?>
<link rel="stylesheet" href="<?= asset_url('assets/css/emails.css') ?>">
<?= $this->endSection() ?>

<?= $this->section('scripts') ?>
<?= $this->include('partials/email_editor_assets') ?>
<script src="<?= asset_url('assets/js/emails.js') ?>"></script>
<?= $this->endSection() ?>
