<?php

declare(strict_types=1);

namespace App\Models;

use App\Models\Concerns\SelfHealingSchema;
use CodeIgniter\Model;

class UserModel extends Model
{
    use SelfHealingSchema;

    protected $table            = 'users';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = true;
    protected $protectFields    = true;
    protected $allowedFields    = [
        'role_id',
        'name',
        'email',
        'password',
        'email_verification_token',
        'email_verification_sent_at',
        'email_verified_at',
        'phone',
        'avatar',
        'status',
        'last_login',
        'remember_token',
    ];

    protected bool $allowEmptyInserts = false;
    protected bool $updateOnlyChanged = true;

    protected $useTimestamps = true;
    protected $dateFormat    = 'datetime';
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';
    protected $deletedField  = 'deleted_at';

    protected $validationRules = [
        'role_id'  => 'required|is_natural_no_zero',
        'name'     => 'required|min_length[2]|max_length[150]',
        'email'    => 'required|valid_email|max_length[191]|is_unique[users.email,id,{id}]',
        'password' => 'permit_empty|min_length[8]|max_length[255]',
        'phone'    => 'permit_empty|max_length[30]',
        'status'   => 'permit_empty|in_list[active,inactive]',
    ];

    protected $validationMessages = [];
    protected $skipValidation     = false;
    protected $cleanValidationRules = true;

    protected $beforeInsert = ['hashPassword'];
    protected $beforeUpdate = ['hashPassword', 'rememberEmailsBeforeUpdate'];
    protected $afterInsert  = ['syncLoginDirectoryAfterInsert'];
    protected $afterUpdate  = ['syncLoginDirectoryAfterUpdate'];
    protected $afterDelete  = ['syncLoginDirectoryAfterDelete'];

    /** @var array<int, string> */
    protected array $emailsBeforeUpdate = [];

    /**
     * @param array<string, mixed> $data
     * @return array<string, mixed>
     */
    protected function hashPassword(array $data): array
    {
        if (! isset($data['data']['password']) || $data['data']['password'] === '') {
            unset($data['data']['password']);

            return $data;
        }

        if (password_get_info($data['data']['password'])['algo'] === null) {
            $data['data']['password'] = password_hash($data['data']['password'], PASSWORD_DEFAULT);

            foreach ((array) ($data['id'] ?? []) as $userId) {
                self::markPasswordChanged((int) $userId);
            }
        }

        return $data;
    }

    /**
     * Sessions that logged in before this moment are signed out by AuthFilter;
     * the user's own current session stays signed in.
     */
    public static function markPasswordChanged(int $userId): void
    {
        if ($userId <= 0) {
            return;
        }

        $now = time();
        cache()->save(self::passwordChangedCacheKey($userId), $now, 30 * DAY);

        $session = session();
        if ((int) $session->get('user_id') === $userId) {
            $session->set('login_at', $now + 1);
        }
    }

    public static function passwordChangedCacheKey(int $userId): string
    {
        return 'pwd_changed_' . md5((\App\Libraries\TenantContext::get() ?? 'default') . '_' . $userId);
    }

    /**
     * @param array<string, mixed> $data
     * @return array<string, mixed>
     */
    protected function rememberEmailsBeforeUpdate(array $data): array
    {
        $this->emailsBeforeUpdate = [];
        $ids = $data['id'] ?? null;
        if ($ids === null) {
            return $data;
        }
        if (! is_array($ids)) {
            $ids = [$ids];
        }
        foreach ($ids as $id) {
            $row = $this->find((int) $id);
            if (is_array($row) && ! empty($row['email'])) {
                $this->emailsBeforeUpdate[(int) $id] = (string) $row['email'];
            }
        }

        return $data;
    }

    /**
     * @param array<string, mixed> $data
     * @return array<string, mixed>
     */
    protected function syncLoginDirectoryAfterInsert(array $data): array
    {
        $email = (string) ($data['data']['email'] ?? '');
        if ($email !== '') {
            (new \App\Libraries\TenantLoginDirectory())->syncEmail($email);
        }

        return $data;
    }

    /**
     * @param array<string, mixed> $data
     * @return array<string, mixed>
     */
    protected function syncLoginDirectoryAfterUpdate(array $data): array
    {
        $ids = $data['id'] ?? null;
        if ($ids === null) {
            return $data;
        }
        if (! is_array($ids)) {
            $ids = [$ids];
        }

        $dir = new \App\Libraries\TenantLoginDirectory();
        foreach ($ids as $id) {
            $id  = (int) $id;
            $row = $this->withDeleted()->find($id);
            if (! is_array($row)) {
                continue;
            }
            $newEmail = (string) ($row['email'] ?? '');
            $oldEmail = $this->emailsBeforeUpdate[$id] ?? null;
            $dir->syncEmail($newEmail, $oldEmail);
        }
        $this->emailsBeforeUpdate = [];

        return $data;
    }

    /**
     * @param array<string, mixed> $data
     * @return array<string, mixed>
     */
    protected function syncLoginDirectoryAfterDelete(array $data): array
    {
        $ids = $data['id'] ?? null;
        if ($ids === null) {
            return $data;
        }
        if (! is_array($ids)) {
            $ids = [$ids];
        }

        $dir = new \App\Libraries\TenantLoginDirectory();
        foreach ($ids as $id) {
            $row = $this->withDeleted()->find((int) $id);
            if (is_array($row) && ! empty($row['email'])) {
                $dir->removeEmail((string) $row['email']);
            }
        }

        return $data;
    }

    /**
     * @return array<string, mixed>|null
     */
    public function findByEmail(string $email): ?array
    {
        $row = $this->where('email', $email)->first();

        return is_array($row) ? $row : null;
    }

    /**
     * @return list<array<string, mixed>>
     */
    public function getActiveUsers(): array
    {
        return $this->where('status', 'active')->orderBy('name', 'ASC')->findAll();
    }

    /**
     * @return array<string, mixed>|null
     */
    public function findByVerificationToken(string $token): ?array
    {
        $row = $this->where('email_verification_token', $token)->first();

        return is_array($row) ? $row : null;
    }
}
