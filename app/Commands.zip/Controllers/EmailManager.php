<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Libraries\ActivityLogger;
use App\Libraries\EmailVerifier;
use App\Libraries\SettingsService;
use App\Models\EmailBuilderModel;
use App\Models\EmailDripModel;
use App\Models\EmailDripStepModel;
use App\Models\EmailHtmlCampaignModel;
use App\Models\EmailLogModel;
use App\Models\EmailSenderModel;
use App\Models\EmailVerificationModel;
use CodeIgniter\HTTP\ResponseInterface;

/**
 * Email Manager — Builder, Drips, Verifier, HTML Campaigns, Sender/Domain IDs.
 * Sends via External (or active email provider) when configured.
 */
class EmailManager extends BaseController
{
    protected const MAX_CAMPAIGN_RECIPIENTS = 100;

    public function index(): string|ResponseInterface
    {
        if ($denied = $this->requirePermission('emails.view')) {
            return $denied;
        }

        $tab = strtolower(trim((string) ($this->request->getGet('tab') ?: 'campaigns')));
        if ($tab === 'analytics') {
            return redirect()->to(site_url('analytics?tab=email'));
        }
        $allowed = ['campaigns', 'builder', 'drips', 'verifier', 'senders'];
        if (! in_array($tab, $allowed, true)) {
            $tab = 'campaigns';
        }

        $settings = new SettingsService();
        $provider = $settings->getEmailProvider();

        $campaignRows = model(EmailHtmlCampaignModel::class)->orderBy('id', 'DESC')->findAll(50);
        $campaigns = [];
        foreach ($campaignRows as $row) {
            if (! is_array($row)) {
                continue;
            }

            $campaigns[] = [
                'id'                 => (int) ($row['id'] ?? 0),
                'name'               => (string) ($row['name'] ?? ('Campaign #' . ((int) ($row['id'] ?? 0)))),
                'subject'            => (string) ($row['subject'] ?? ''),
                'status'             => (string) ($row['status'] ?? 'draft'),
                'sent_count'         => (int) ($row['sent_count'] ?? 0),
                'failed_count'       => (int) ($row['failed_count'] ?? 0),
                'builder_id'         => ! empty($row['builder_id']) ? (int) $row['builder_id'] : null,
                'cheerio_builder_id' => isset($row['cheerio_builder_id']) ? (string) $row['cheerio_builder_id'] : null,
                'mode'               => (string) ($row['mode'] ?? 'recipients'),
                'label_name'         => isset($row['label_name']) ? (string) $row['label_name'] : null,
                'recipients'         => is_array($row['recipients'] ?? null) ? $row['recipients'] : [],
                'html_content'       => (string) ($row['html_content'] ?? ''),
                'last_error'         => isset($row['last_error']) ? (string) $row['last_error'] : null,
            ];
        }

        $tagModel = model(\App\Models\TagModel::class);
        $customerGroups = $tagModel->listWithContactCounts();

        return $this->render('email_manager/index', [
            'pageTitle'          => 'Email Manager',
            'activeTab'          => $tab,
            'provider'           => $provider,
            'providerLabel'      => $this->providerLabel($provider),
            'isCheerio'          => $provider === SettingsService::EMAIL_PROVIDER_CHEERIO,
            'isSes'              => $provider === SettingsService::EMAIL_PROVIDER_SES,
            'builders'           => model(EmailBuilderModel::class)->orderBy('id', 'DESC')->findAll(100),
            'drips'              => model(EmailDripModel::class)->withSteps(50),
            'campaigns'          => $campaigns,
            'customerGroups'     => $customerGroups,
            'senders'            => model(EmailSenderModel::class)->orderBy('type', 'ASC')->orderBy('id', 'DESC')->findAll(100),
            'verifications'      => model(EmailVerificationModel::class)->orderBy('id', 'DESC')->findAll(50),
            'defaultCampaign'    => (string) $settings->get('cheerio_email_campaign_name', 'app-direct'),
            'reputation'         => (new \App\Libraries\EmailReputationGuard())->status(),
            'companyAddress'     => \App\Libraries\EmailTracking::companyAddress(),
        ]);
    }

    public function getGroupEmails(int $tagId): ResponseInterface
    {
        if ($denied = $this->requirePermission('emails.view')) {
            return $denied;
        }

        /** @var \App\Models\TagModel $tagModel */
        $tagModel = model(\App\Models\TagModel::class);
        $contacts = $tagModel->getContacts($tagId);

        $emails = [];
        foreach ($contacts as $c) {
            $em = strtolower(trim((string) ($c['email'] ?? '')));
            if ($em !== '' && filter_var($em, FILTER_VALIDATE_EMAIL)) {
                $emails[] = $em;
            }
        }
        $emails = array_values(array_unique($emails));

        /** @var \App\Models\EmailUnsubscribeModel $unsubModel */
        $unsubModel = model(\App\Models\EmailUnsubscribeModel::class);
        $activeEmails = $unsubModel->filterActiveRecipients($emails);
        $unsubCount = count($emails) - count($activeEmails);

        return $this->jsonResponse(true, [
            'emails'       => $activeEmails,
            'total'        => count($emails),
            'active_count' => count($activeEmails),
            'unsub_count'  => $unsubCount,
        ], 'Group contacts retrieved.');
    }

    // ─── Builders ───────────────────────────────────────────────

    public function saveBuilder(): ResponseInterface
    {
        if ($denied = $this->requirePermission('emails.send')) {
            return $denied;
        }

        $input = $this->requestInput();
        $id    = (int) ($input['id'] ?? 0);
        $name  = trim((string) ($input['name'] ?? ''));
        $subject = trim((string) ($input['subject'] ?? ''));
        $html  = (string) ($input['html_content'] ?? '');
        $cheerioId = trim((string) ($input['cheerio_builder_id'] ?? ''));
        $status = (string) ($input['status'] ?? 'draft');
        if (! in_array($status, ['draft', 'active', 'archived'], true)) {
            $status = 'draft';
        }

        if ($name === '') {
            return $this->jsonResponse(false, null, 'Builder name is required.', ['name' => 'Required'], 422);
        }

        $row = [
            'name'               => $name,
            'subject'            => $subject !== '' ? $subject : null,
            'html_content'       => $html,
            'cheerio_builder_id' => $cheerioId !== '' ? $cheerioId : null,
            'status'             => $status,
        ];

        $attFile = $this->request->getFile('attachment');
        if ($attFile !== null && $attFile->isValid() && ! $attFile->hasMoved()) {
            $attRes = \App\Libraries\EmailAttachmentHandler::handleUpload($attFile);
            if (! $attRes['ok']) {
                return $this->jsonResponse(false, null, $attRes['error'] ?? 'Attachment upload error', ['attachment' => $attRes['error']], 422);
            }
            $row['attachment_path'] = $attRes['relative_path'];
            $row['attachment_name'] = $attRes['name'];
        } elseif (! empty($input['remove_attachment'])) {
            $row['attachment_path'] = null;
            $row['attachment_name'] = null;
        }

        $model = model(EmailBuilderModel::class);
        try {
            if ($id > 0) {
                $existing = $model->find($id);
                if (! $existing) {
                    return $this->jsonResponse(false, null, 'Builder not found.', [], 404);
                }
                $model->update($id, $row);
            } else {
                $row['created_by'] = (int) ($this->currentUser['id'] ?? 0) ?: null;
                $id = (int) $model->insert($row, true);
            }

            $saved = $model->find($id);
            (new ActivityLogger())->log('email_builder_save', 'emails', 'Saved email builder: ' . $name, ['id' => $id]);

            return $this->jsonResponse(true, $saved, 'Builder saved.');
        } catch (\Throwable $e) {
            return $this->jsonResponse(false, null, $e->getMessage(), [], 500);
        }
    }

    public function deleteBuilder(int $id): ResponseInterface
    {
        if ($denied = $this->requirePermission('emails.delete')) {
            return $denied;
        }

        $model = model(EmailBuilderModel::class);
        $row   = $model->find($id);
        if (! $row) {
            return $this->jsonResponse(false, null, 'Builder not found.', [], 404);
        }

        $model->delete($id);
        (new ActivityLogger())->log('email_builder_delete', 'emails', 'Deleted email builder #' . $id);

        return $this->jsonResponse(true, null, 'Builder deleted.');
    }

    // ─── Drips ──────────────────────────────────────────────────

    public function saveDrip(): ResponseInterface
    {
        if ($denied = $this->requirePermission('emails.send')) {
            return $denied;
        }

        $input = $this->requestInput();
        $id    = (int) ($input['id'] ?? 0);
        $name  = trim((string) ($input['name'] ?? ''));
        if ($name === '') {
            return $this->jsonResponse(false, null, 'Drip name is required.', ['name' => 'Required'], 422);
        }

        $trigger = (string) ($input['trigger_type'] ?? 'manual');
        if (! in_array($trigger, ['manual', 'on_subscribe', 'on_tag'], true)) {
            $trigger = 'manual';
        }
        $status = (string) ($input['status'] ?? 'draft');
        if (! in_array($status, ['draft', 'active', 'paused', 'archived'], true)) {
            $status = 'draft';
        }

        $dripModel = model(EmailDripModel::class);
        $stepModel = model(EmailDripStepModel::class);

        $payload = [
            'name'          => $name,
            'description'   => trim((string) ($input['description'] ?? '')) ?: null,
            'trigger_type'  => $trigger,
            'trigger_value' => trim((string) ($input['trigger_value'] ?? '')) ?: null,
            'status'        => $status,
        ];

        $db = db_connect();
        $db->transStart();

        try {
            if ($id > 0) {
                if (! $dripModel->find($id)) {
                    return $this->jsonResponse(false, null, 'Drip not found.', [], 404);
                }
                $dripModel->update($id, $payload);
                $stepModel->where('drip_id', $id)->delete();
            } else {
                $payload['created_by'] = (int) ($this->currentUser['id'] ?? 0) ?: null;
                $id = (int) $dripModel->insert($payload, true);
            }

            $steps = $input['steps'] ?? [];
            if (is_string($steps)) {
                $decoded = json_decode($steps, true);
                $steps   = is_array($decoded) ? $decoded : [];
            }

            $order = 1;
            if (is_array($steps)) {
                foreach ($steps as $step) {
                    if (! is_array($step)) {
                        continue;
                    }
                    $subject = trim((string) ($step['subject'] ?? ''));
                    if ($subject === '') {
                        continue;
                    }
                    $stepModel->insert([
                        'drip_id'      => $id,
                        'step_order'   => $order++,
                        'delay_hours'  => max(0, (int) ($step['delay_hours'] ?? 0)),
                        'subject'      => $subject,
                        'html_content' => (string) ($step['html_content'] ?? ''),
                        'builder_id'   => ! empty($step['builder_id']) ? (int) $step['builder_id'] : null,
                    ]);
                }
            }

            $db->transComplete();
            if (! $db->transStatus()) {
                return $this->jsonResponse(false, null, 'Failed to save drip.', [], 500);
            }

            $saved = $dripModel->withSteps();
            $match = null;
            foreach ($saved as $d) {
                if ((int) $d['id'] === $id) {
                    $match = $d;
                    break;
                }
            }

            (new ActivityLogger())->log('email_drip_save', 'emails', 'Saved email drip: ' . $name, ['id' => $id]);

            return $this->jsonResponse(true, $match, 'Drip saved.');
        } catch (\Throwable $e) {
            $db->transRollback();

            return $this->jsonResponse(false, null, $e->getMessage(), [], 500);
        }
    }

    public function duplicateDrip(int $id): ResponseInterface
    {
        if ($denied = $this->requirePermission('emails.send')) {
            return $denied;
        }

        $newId = model(EmailDripModel::class)->duplicateRow($id, (int) ($this->currentUser['id'] ?? 0) ?: null);
        if ($newId === null) {
            return $this->jsonResponse(false, null, 'Drip not found.', [], 404);
        }

        $copy = model(EmailDripModel::class)->find($newId);
        log_activity('create', 'emails', 'Duplicated email workflow: ' . (string) ($copy['name'] ?? ('#' . $newId)), [
            'id'        => $newId,
            'source_id' => $id,
        ]);

        return $this->jsonResponse(true, ['id' => $newId], 'Workflow duplicated as a draft.');
    }

    public function deleteDrip(int $id): ResponseInterface
    {
        if ($denied = $this->requirePermission('emails.delete')) {
            return $denied;
        }

        $model = model(EmailDripModel::class);
        if (! $model->find($id)) {
            return $this->jsonResponse(false, null, 'Drip not found.', [], 404);
        }
        $model->delete($id);
        (new ActivityLogger())->log('email_drip_delete', 'emails', 'Deleted email drip #' . $id);

        return $this->jsonResponse(true, null, 'Drip deleted.');
    }

    public function sendDripStep(): ResponseInterface
    {
        if ($denied = $this->requirePermission('emails.send')) {
            return $denied;
        }

        $input  = $this->requestInput();
        $dripId = (int) ($input['drip_id'] ?? 0);
        $stepId = (int) ($input['step_id'] ?? 0);
        $to     = trim((string) ($input['to'] ?? ''));

        if ($to === '' || ! filter_var($to, FILTER_VALIDATE_EMAIL)) {
            return $this->jsonResponse(false, null, 'Valid recipient email required.', ['to' => 'Invalid'], 422);
        }

        $drip = model(EmailDripModel::class)->find($dripId);
        $step = model(EmailDripStepModel::class)->find($stepId);
        if (! $drip || ! $step || (int) $step['drip_id'] !== $dripId) {
            return $this->jsonResponse(false, null, 'Drip step not found.', [], 404);
        }

        $html    = (string) ($step['html_content'] ?? '');
        $options = [];
        $builderId = null;

        if (! empty($step['builder_id'])) {
            $builder = model(EmailBuilderModel::class)->find((int) $step['builder_id']);
            if ($builder) {
                $builderId = (int) $builder['id'];
                if ($html === '' && ! empty($builder['html_content'])) {
                    $html = (string) $builder['html_content'];
                }
                if (! empty($builder['cheerio_builder_id'])) {
                    $options['email_builder_id'] = (string) $builder['cheerio_builder_id'];
                }
            }
        }

        if ($html === '' && empty($options['email_builder_id'])) {
            return $this->jsonResponse(false, null, 'Step has no HTML content or builder.', [], 422);
        }

        $suppressed = (new \App\Libraries\EmailSuppressionService())->reasonFor($to, true);
        if ($suppressed !== null) {
            $message = sprintf('Skipped: %s %s, so this drip email was not sent.', $to, \App\Libraries\EmailSuppressionService::reasonLabel($suppressed));

            return $this->jsonResponse(false, ['skipped' => [strtolower($to) => $suppressed]], $message, ['to' => $message], 422);
        }

        $perRecipient = (new SettingsService())->getEmailProvider() !== SettingsService::EMAIL_PROVIDER_CHEERIO;
        $options['unsubscribe_url'] = \App\Libraries\EmailTracking::unsubscribeUrl(0, $perRecipient);
        $options['purpose']         = EmailSenderModel::PURPOSE_MARKETING;
        if ($html !== '') {
            $html = \App\Libraries\EmailTracking::applyMarketingFooter($html, $options['unsubscribe_url']);
        }

        try {
            $mailer = service('emailProvider');
            $result = $mailer->sendHtml($to, (string) $step['subject'], $html !== '' ? $html : '<p></p>', $options);
            $ok     = (bool) ($result['ok'] ?? false);

            model(EmailLogModel::class)->record(
                'drip',
                $ok ? 'sent' : 'failed',
                (string) $step['subject'],
                $to,
                (string) ($result['provider'] ?? ''),
                (string) ($result['message'] ?? ''),
                ['drip_id' => $dripId, 'step_id' => $stepId],
                (int) ($this->currentUser['id'] ?? 0) ?: null,
                $builderId,
                null,
                $dripId
            );
            log_activity($ok ? 'email_drip_step_sent' : 'email_drip_step_failed', 'emails', ($ok ? 'Sent' : 'Failed to send') . ' drip step to ' . $to, [
                'drip_id' => $dripId,
                'step_id' => $stepId,
                'to'      => $to,
            ]);

            return $this->jsonResponse($ok, $result, $ok ? 'Drip step sent via provider.' : (string) ($result['message'] ?? 'Send failed.'));
        } catch (\Throwable $e) {
            return $this->jsonResponse(false, null, $e->getMessage(), [], 500);
        }
    }

    // ─── Verifier ───────────────────────────────────────────────

    public function verifyEmails(): ResponseInterface
    {
        if ($denied = $this->requirePermission('emails.send')) {
            return $denied;
        }

        $input = $this->requestInput();
        $raw   = (string) ($input['emails'] ?? $input['email'] ?? '');
        $parts = preg_split('/[\s,;]+/', $raw) ?: [];
        $list  = [];
        foreach ($parts as $p) {
            $p = trim($p);
            if ($p !== '') {
                $list[] = $p;
            }
        }

        if ($list === []) {
            return $this->jsonResponse(false, null, 'Provide at least one email.', ['emails' => 'Required'], 422);
        }

        $verifier = new EmailVerifier();
        $results  = $verifier->verifyMany($list, 50);
        $model    = model(EmailVerificationModel::class);
        $saved    = [];

        foreach ($results as $r) {
            $existing = $model->where('email', $r['email'])->first();
            $row = [
                'email'       => $r['email'],
                'status'      => $r['status'],
                'syntax_ok'   => $r['syntax_ok'] ? 1 : 0,
                'mx_ok'       => $r['mx_ok'] ? 1 : 0,
                'disposable'  => $r['disposable'] ? 1 : 0,
                'checks_json' => $r['checks'],
                'verified_at' => date('Y-m-d H:i:s'),
            ];
            if ($existing) {
                $model->update((int) $existing['id'], $row);
                $row['id'] = (int) $existing['id'];
            } else {
                $row['id'] = (int) $model->insert($row, true);
            }
            $row['checks'] = $r['checks'];
            $saved[] = $row;
        }

        return $this->jsonResponse(true, ['results' => $saved], 'Verification complete.');
    }

    // ─── HTML Campaigns ─────────────────────────────────────────

    public function saveCampaign(): ResponseInterface
    {
        if ($denied = $this->requirePermission('emails.send')) {
            return $denied;
        }

        $input   = $this->requestInput();
        $id      = (int) ($input['id'] ?? 0);
        $name    = trim((string) ($input['name'] ?? ''));
        $subject = trim((string) ($input['subject'] ?? ''));
        $html    = (string) ($input['html_content'] ?? '');
        $mode      = strtolower(trim((string) ($input['mode'] ?? 'recipients')));
        if (! in_array($mode, ['recipients', 'label'], true)) {
            $mode = 'recipients';
        }
        $labelName = trim((string) ($input['label_name'] ?? ''));

        if ($name === '' || $subject === '') {
            return $this->jsonResponse(false, null, 'Name and subject are required.', [], 422);
        }

        $recipients = [];
        $raw = (string) ($input['recipients'] ?? '');
        if ($raw !== '') {
            $parts = preg_split('/[\s,;]+/', $raw) ?: [];
            foreach ($parts as $p) {
                $p = strtolower(trim($p));
                if ($p !== '' && filter_var($p, FILTER_VALIDATE_EMAIL)) {
                    $recipients[] = $p;
                }
            }
            $recipients = array_values(array_unique($recipients));
        }
        if (isset($input['recipients']) && is_array($input['recipients'])) {
            foreach ($input['recipients'] as $p) {
                $p = strtolower(trim((string) $p));
                if ($p !== '' && filter_var($p, FILTER_VALIDATE_EMAIL)) {
                    $recipients[] = $p;
                }
            }
            $recipients = array_values(array_unique($recipients));
        }

        // Auto-resolve contacts from customer group if recipients list is empty
        if ($recipients === [] && $labelName !== '') {
            $tagModel = model(\App\Models\TagModel::class);
            $tagRow   = $tagModel->where('name', $labelName)->first();
            if (! $tagRow && ctype_digit($labelName)) {
                $tagRow = $tagModel->find((int) $labelName);
            }
            if ($tagRow) {
                $groupContacts = model(\App\Models\ContactModel::class)
                    ->select('contacts.email')
                    ->join('contact_tags', 'contact_tags.contact_id = contacts.id')
                    ->where('contact_tags.tag_id', (int) $tagRow['id'])
                    ->where('contacts.email !=', '')
                    ->where('contacts.email IS NOT NULL', null, false)
                    ->findAll();
                foreach ($groupContacts as $row) {
                    $em = strtolower(trim((string) ($row['email'] ?? '')));
                    if ($em !== '' && filter_var($em, FILTER_VALIDATE_EMAIL)) {
                        $recipients[] = $em;
                    }
                }
                $recipients = array_values(array_unique($recipients));
            }
        }

        if ($recipients === [] && $mode !== 'label') {
            return $this->jsonResponse(false, null, 'Please add at least one recipient email address or import a customer group.', [], 422);
        }

        if (count($recipients) > self::MAX_CAMPAIGN_RECIPIENTS) {
            return $this->jsonResponse(false, null, 'Max ' . self::MAX_CAMPAIGN_RECIPIENTS . ' recipients.', [], 422);
        }

        $builderId = ! empty($input['builder_id']) ? (int) $input['builder_id'] : null;
        $cheerioBuilderId = trim((string) ($input['cheerio_builder_id'] ?? ''));

        if ($builderId) {
            $builder = model(EmailBuilderModel::class)->find($builderId);
            if ($builder) {
                if ($html === '' && ! empty($builder['html_content'])) {
                    $html = (string) $builder['html_content'];
                }
                if ($cheerioBuilderId === '' && ! empty($builder['cheerio_builder_id'])) {
                    $cheerioBuilderId = (string) $builder['cheerio_builder_id'];
                }
            }
        }

        $row = [
            'name'               => $name,
            'subject'            => $subject,
            'html_content'       => $html,
            'builder_id'         => $builderId,
            'cheerio_builder_id' => $cheerioBuilderId !== '' ? $cheerioBuilderId : null,
            'mode'               => $mode,
            'label_name'         => trim((string) ($input['label_name'] ?? '')) ?: null,
            'recipients_json'    => $recipients,
            'status'             => 'draft',
        ];

        $attFile = $this->request->getFile('attachment');
        if ($attFile !== null && $attFile->isValid() && ! $attFile->hasMoved()) {
            $attRes = \App\Libraries\EmailAttachmentHandler::handleUpload($attFile);
            if (! $attRes['ok']) {
                return $this->jsonResponse(false, null, $attRes['error'] ?? 'Attachment upload error', ['attachment' => $attRes['error']], 422);
            }
            $row['attachment_path'] = $attRes['relative_path'];
            $row['attachment_name'] = $attRes['name'];
        } elseif (! empty($input['remove_attachment'])) {
            $row['attachment_path'] = null;
            $row['attachment_name'] = null;
        }

        $model = model(EmailHtmlCampaignModel::class);
        try {
            if ($id > 0) {
                if (! $model->find($id)) {
                    return $this->jsonResponse(false, null, 'Campaign not found.', [], 404);
                }
                $model->update($id, $row);
            } else {
                $row['created_by'] = (int) ($this->currentUser['id'] ?? 0) ?: null;
                $id = (int) $model->insert($row, true);
            }

            (new ActivityLogger())->log('email_campaign_save', 'emails', 'Saved HTML email campaign: ' . $name, ['id' => $id]);

            return $this->jsonResponse(true, $model->find($id), 'Campaign saved.');
        } catch (\Throwable $e) {
            return $this->jsonResponse(false, null, $e->getMessage(), [], 500);
        }
    }

    public function sendCampaign(int $id): ResponseInterface
    {
        if ($denied = $this->requirePermission('emails.send')) {
            return $denied;
        }

        $model = model(EmailHtmlCampaignModel::class);
        $camp  = $model->find($id);
        if (! $camp) {
            return $this->jsonResponse(false, null, 'Campaign not found.', [], 404);
        }

        try {
            $actorId = (int) ($this->currentUser['id'] ?? 0) ?: null;
            $result  = (new \App\Libraries\EmailCampaignService())->dispatch($camp, $actorId);
            $ok      = (bool) ($result['ok'] ?? false);

            (new ActivityLogger())->log('email_campaign_send', 'emails', 'Dispatched HTML email campaign: ' . ($camp['name'] ?? ('#' . $id)), [
                'id'      => $id,
                'ok'      => $ok,
                'skipped' => count((array) ($result['skipped'] ?? [])),
                'paused'  => ! empty($result['paused']),
            ]);

            return $this->jsonResponse(
                $ok,
                $model->find($id),
                (string) ($result['message'] ?? ($ok ? 'Campaign sent.' : 'Failed')),
                [],
                $ok ? 200 : (! empty($result['paused']) ? 409 : 200)
            );
        } catch (\Throwable $e) {
            $model->update($id, ['status' => 'failed', 'last_error' => $e->getMessage()]);

            return $this->jsonResponse(false, null, $e->getMessage(), [], 500);
        }
    }

    public function deleteCampaign(int $id): ResponseInterface
    {
        if ($denied = $this->requirePermission('emails.delete')) {
            return $denied;
        }

        $model = model(EmailHtmlCampaignModel::class);
        if (! $model->find($id)) {
            return $this->jsonResponse(false, null, 'Campaign not found.', [], 404);
        }
        $model->delete($id);
        (new ActivityLogger())->log('email_campaign_delete', 'emails', 'Deleted HTML email campaign #' . $id, ['id' => $id]);

        return $this->jsonResponse(true, null, 'Campaign deleted.');
    }

    // ─── Senders / Domains ──────────────────────────────────────

    public function saveSender(): ResponseInterface
    {
        if ($denied = $this->requirePermission('emails.send')) {
            return $denied;
        }

        $input = $this->requestInput();
        $id    = (int) ($input['id'] ?? 0);
        $type  = (string) ($input['type'] ?? 'sender');
        if (! in_array($type, ['sender', 'domain'], true)) {
            $type = 'sender';
        }
        $name = trim((string) ($input['name'] ?? ''));
        if ($name === '') {
            return $this->jsonResponse(false, null, 'Name is required.', ['name' => 'Required'], 422);
        }

        $status = (string) ($input['status'] ?? 'pending');
        if (! in_array($status, ['pending', 'verified', 'failed', 'disabled'], true)) {
            $status = 'pending';
        }

        $dns = $input['dns_records'] ?? null;
        if (is_string($dns) && $dns !== '') {
            $decoded = json_decode($dns, true);
            $dns = is_array($decoded) ? $decoded : ['notes' => $dns];
        }

        $row = [
            'type'        => $type,
            'name'        => $name,
            'email'       => trim((string) ($input['email'] ?? '')) ?: null,
            'domain'      => trim((string) ($input['domain'] ?? '')) ?: null,
            'cheerio_id'  => trim((string) ($input['cheerio_id'] ?? '')) ?: null,
            'status'      => $status,
            'dns_records' => is_array($dns) ? $dns : null,
            'notes'       => trim((string) ($input['notes'] ?? '')) ?: null,
            'is_default'  => ! empty($input['is_default']) ? 1 : 0,
        ];

        if ($type === 'sender' && empty($row['email'])) {
            return $this->jsonResponse(false, null, 'Sender email is required.', ['email' => 'Required'], 422);
        }
        if ($type === 'domain' && empty($row['domain'])) {
            return $this->jsonResponse(false, null, 'Domain is required.', ['domain' => 'Required'], 422);
        }

        $model = model(EmailSenderModel::class);
        try {
            if (! empty($row['is_default'])) {
                $purpose = EmailSenderModel::normalizePurpose($id > 0 ? ($model->find($id)['purpose'] ?? null) : null);
                $model->where('type', $type)->where('purpose', $purpose)->set(['is_default' => 0])->update();
            }

            if ($id > 0) {
                $existing = $model->find($id);
                if (! $existing) {
                    return $this->jsonResponse(false, null, 'Record not found.', [], 404);
                }
                // Amazon SES identities: DNS records + status are owned by AWS (see sesCheck).
                if (($existing['provider'] ?? '') === \App\Libraries\SesIdentityService::PROVIDER) {
                    unset($row['dns_records'], $row['status'], $row['type'], $row['domain']);
                }
                $model->update($id, $row);
            } else {
                $id = (int) $model->insert($row, true);
            }

            return $this->jsonResponse(true, $model->find($id), 'Saved. Verify this Sender/Domain in External Dashboard for delivery.');
        } catch (\Throwable $e) {
            return $this->jsonResponse(false, null, $e->getMessage(), [], 500);
        }
    }

    public function deleteSender(int $id): ResponseInterface
    {
        if ($denied = $this->requirePermission('emails.delete')) {
            return $denied;
        }

        $model = model(EmailSenderModel::class);
        $row   = $model->find($id);
        if (! $row) {
            return $this->jsonResponse(false, null, 'Record not found.', [], 404);
        }
        $model->delete($id);
        (new \App\Libraries\SesIdentityService())->forgetDefaultSender($row);
        log_activity('email_sender_deleted', 'emails', 'Deleted ' . ($row['type'] ?? 'sender') . ' ' . ($row['email'] ?? $row['domain'] ?? $row['name'] ?? ('#' . $id)), [
            'id'       => $id,
            'type'     => $row['type'] ?? null,
            'provider' => $row['provider'] ?? null,
        ]);

        return $this->jsonResponse(true, null, 'Deleted.');
    }

    /**
     * Add a From address on an Amazon SES domain.
     * POST email-manager/ses-senders
     */
    public function sesAddSender(): ResponseInterface
    {
        if ($denied = $this->requirePermission('emails.send')) {
            return $denied;
        }

        return $this->sesResult((new \App\Libraries\SesIdentityService())->addSender($this->requestInput()));
    }

    /**
     * Make a sender the default Amazon SES From address.
     * POST email-manager/ses-senders/{id}/default
     */
    public function sesDefaultSender(int $id): ResponseInterface
    {
        if ($denied = $this->requirePermission('emails.send')) {
            return $denied;
        }

        return $this->sesResult((new \App\Libraries\SesIdentityService())->setDefaultSender($id));
    }

    /**
     * Start Amazon SES setup for a domain (+ From email/name) and return DNS records.
     * POST email-manager/ses-identities
     */
    public function sesConfigure(): ResponseInterface
    {
        if ($denied = $this->requirePermission('emails.send')) {
            return $denied;
        }

        return $this->sesResult((new \App\Libraries\SesIdentityService())->configure($this->requestInput()));
    }

    /**
     * Re-check Amazon SES verification + live DNS for a configured domain.
     * POST email-manager/ses-identities/check
     */
    public function sesCheck(): ResponseInterface
    {
        if ($denied = $this->requirePermission('emails.send')) {
            return $denied;
        }

        $domain = trim((string) ($this->requestInput()['domain'] ?? ''));
        if ($domain === '') {
            return $this->jsonResponse(false, null, 'Domain is required.', ['domain' => 'Required'], 422);
        }

        return $this->sesResult((new \App\Libraries\SesIdentityService())->refresh($domain));
    }

    /**
     * One-click SES → SNS → webhook wiring for delivery / bounce / complaint tracking.
     * POST email-manager/ses-bounce-tracking
     */
    public function sesBounceConnect(): ResponseInterface
    {
        if ($denied = $this->requirePermission('emails.send')) {
            return $denied;
        }

        return $this->sesResult((new \App\Libraries\SesBounceTrackingService())->connect());
    }

    /**
     * GET email-manager/ses-bounce-tracking
     */
    public function sesBounceStatus(): ResponseInterface
    {
        if ($denied = $this->requirePermission('emails.view')) {
            return $denied;
        }

        return $this->jsonResponse(true, (new \App\Libraries\SesBounceTrackingService())->status());
    }

    /**
     * @param array{ok: bool, status: int, message: string, data?: mixed, errors?: array<string, string>} $result
     */
    protected function sesResult(array $result): ResponseInterface
    {
        return $this->jsonResponse(
            $result['ok'],
            $result['data'] ?? null,
            $result['message'],
            $result['errors'] ?? [],
            $result['ok'] ? 200 : $result['status']
        );
    }

    protected function providerLabel(string $provider): string
    {
        return (new SettingsService())->emailProviderLabel($provider);
    }
}
