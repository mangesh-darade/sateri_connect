<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Libraries\ActivityLogger;
use App\Libraries\CheerioDirectAPI;
use App\Libraries\ContactAttributes;
use App\Libraries\ContactListFilter;
use App\Libraries\WhatsAppTemplatePayload;
use App\Models\ContactModel;
use App\Models\ConversationModel;
use App\Models\InternalNoteModel;
use App\Models\MediaModel;
use App\Models\MessageModel;
use App\Models\TagModel;
use App\Models\TemplateModel;
use App\Models\UserModel;
use CodeIgniter\HTTP\ResponseInterface;
use Throwable;

/**
 * WhatsApp-style inbox: conversations, messages, send, notes.
 */
class Chat extends BaseController
{
    public function index(): string|ResponseInterface
    {
        if ($denied = $this->requirePermission('chat.view')) {
            return $denied;
        }

        $contactId = (int) ($this->request->getGet('contact_id') ?? 0);
        $channel   = strtolower(trim((string) ($this->request->getGet('channel') ?? 'whatsapp')));
        if (! in_array($channel, ['all', 'whatsapp', 'instagram', 'messenger'], true)) {
            $channel = 'whatsapp';
        }
        $settings  = service('settingsService');
        $activeWh  = $settings->getActiveWebhookConfig();
        $publicBase = trim((string) $settings->get('webhook_public_base', ''));
        $pageApi   = service('pageMessaging');

        $channelLabels = [
            'all'       => ['title' => 'Team Inbox', 'subtitle' => 'All channels'],
            'whatsapp'  => ['title' => (string) (setting('business_phone', 'WhatsApp Inbox') ?? 'WhatsApp Inbox'), 'subtitle' => 'WABA Number'],
            'instagram' => ['title' => 'Instagram Inbox', 'subtitle' => 'Instagram Messaging'],
            'messenger' => ['title' => 'Messenger Inbox', 'subtitle' => 'Facebook Messenger'],
        ];

        return $this->render('chat/index', [
            'pageTitle'       => $channelLabels[$channel]['title'] ?? 'Inbox',
            'chatPage'        => true,
            'inboxChannel'    => $channel,
            'inboxTitle'      => $channelLabels[$channel]['title'] ?? 'Inbox',
            'inboxSubtitle'   => $channelLabels[$channel]['subtitle'] ?? '',
            'instagramEnabled'=> $settings->isInstagramInboxEnabled() && $pageApi->isConfigured(),
            'messengerEnabled'=> $settings->isMessengerInboxEnabled() && $pageApi->isConfigured(),
            'selectedContact' => $contactId > 0 ? model(ContactModel::class)->getWithTags($contactId) : null,
            'templates'       => model(TemplateModel::class)
                ->where('status', 'APPROVED')
                ->orderBy('name', 'ASC')
                ->findAll(100),
            'agents'          => model(UserModel::class)
                ->where('status', 'active')
                ->orderBy('name', 'ASC')
                ->findAll(200),
            'webhookReady'    => $publicBase !== ''
                && str_starts_with($publicBase, 'https://')
                && trim((string) ($activeWh['verify_token'] ?? '')) !== '',
            'whatsappProvider'=> $settings->getWhatsAppProvider(),
            'tags'            => model(TagModel::class)->orderBy('name', 'ASC')->findAll(),
            'attributeKeys'   => ContactAttributes::knownKeys(),
            'attributeDefs'   => service('contactAttributes')->definitions(),
            'attributeOps'    => ContactListFilter::ATTRIBUTE_OPS,
        ]);
    }

    /**
     * Inbox contact panel: consent, groups (tags) and attributes for the open chat.
     */
    public function contactPanel(int $contactId): ResponseInterface
    {
        if ($denied = $this->requirePermission('chat.view')) {
            return $denied;
        }
        $payload = $this->contactPanelPayload($contactId);

        return $payload === null
            ? $this->jsonResponse(false, null, 'Contact not found.', [], 404)
            : $this->jsonResponse(true, $payload);
    }

    public function saveContactAttribute(): ResponseInterface
    {
        if ($denied = $this->requirePermission('chat.send')) {
            return $denied;
        }
        $input     = $this->requestInput();
        $contactId = (int) ($input['contact_id'] ?? 0);
        $key       = trim((string) ($input['key'] ?? ''));
        try {
            $value = service('contactAttributes')->setContactValue($contactId, $key, (string) ($input['value'] ?? ''));
        } catch (\InvalidArgumentException $e) {
            return $this->jsonResponse(false, null, $e->getMessage(), [], 422);
        }
        $label = service('contactAttributes')->label($key);

        return $this->jsonResponse(true, ['key' => $key, 'value' => $value], $value === '' ? "{$label} cleared." : "{$label} saved.");
    }

    public function contactTag(): ResponseInterface
    {
        if ($denied = $this->requirePermission('chat.send')) {
            return $denied;
        }
        $input     = $this->requestInput();
        $contactId = (int) ($input['contact_id'] ?? 0);
        $action    = (string) ($input['action'] ?? 'add');
        $tags      = model(TagModel::class);
        if ($contactId <= 0 || model(ContactModel::class)->find($contactId) === null) {
            return $this->jsonResponse(false, null, 'Contact not found.', [], 404);
        }

        $tagId = (int) ($input['tag_id'] ?? 0);
        $name  = trim((string) ($input['tag_name'] ?? ''));
        if ($tagId <= 0 && $name !== '' && $action === 'add') {
            if (mb_strlen($name) > 100) {
                return $this->jsonResponse(false, null, 'Group name is too long (max 100 characters).', [], 422);
            }
            $tagId = (int) ($tags->findOrCreateByName($name)['id'] ?? 0);
        }
        if ($tagId <= 0 || $tags->find($tagId) === null) {
            return $this->jsonResponse(false, null, 'Choose a group.', [], 422);
        }

        if ($action === 'remove') {
            $tags->detachContact($tagId, $contactId);
        } else {
            $tags->attachContact($tagId, $contactId);
        }

        return $this->jsonResponse(true, $this->contactPanelPayload($contactId), $action === 'remove' ? 'Removed from group.' : 'Added to group.');
    }

    /**
     * Quick replies with {{placeholders}} filled for the open chat.
     */
    public function quickReplies(): ResponseInterface
    {
        if ($denied = $this->requirePermission('chat.view')) {
            return $denied;
        }
        $service = service('quickReplies');
        $contact = model(ContactModel::class)->find((int) ($this->request->getGet('contact_id') ?? 0)) ?? [];
        $rows    = array_map(static fn (array $r): array => [
            'shortcut' => $r['shortcut'],
            'title'    => $r['title'],
            'message'  => $service->render((string) $r['message'], $contact),
        ], $service->all());

        return $this->jsonResponse(true, ['quick_replies' => $rows]);
    }

    /**
     * @return array<string, mixed>|null
     */
    protected function contactPanelPayload(int $contactId): ?array
    {
        $contact = model(ContactModel::class)->find($contactId);
        if (! is_array($contact)) {
            return null;
        }
        $consent = service('whatsAppConsent');
        $state   = 'none';
        if ($consent->hasConsentColumns()) {
            $state = ! empty($contact['wa_opted_out_at']) ? 'opted_out' : ((int) ($contact['wa_opt_in'] ?? 0) === 1 ? 'opted_in' : 'no_opt_in');
        }
        $core = [];
        foreach (['email', 'country', 'birthday', 'status'] as $key) {
            $core[] = ['key' => $key, 'label' => ucfirst($key), 'type' => $key === 'birthday' ? 'date' : ($key === 'status' ? 'dropdown' : 'text'),
                'options' => $key === 'status' ? ['active', 'inactive', 'blocked'] : [], 'value' => (string) ($contact[$key] ?? ''), 'defined' => true];
        }

        return [
            'contact'    => [
                'id'      => (int) $contact['id'],
                'name'    => (string) ($contact['name'] ?? ''),
                'mobile'  => (string) ($contact['mobile'] ?? ''),
                'consent' => $state,
                'url'     => site_url('contacts/' . (int) $contact['id']),
            ],
            'tags'       => model(TagModel::class)->getForContact($contactId),
            'all_tags'   => model(TagModel::class)->select('id, name, color')->orderBy('name', 'ASC')->findAll(),
            'core'       => $core,
            'attributes' => service('contactAttributes')->contactRows($contact),
        ];
    }

    public function conversations(): ResponseInterface
    {
        if ($denied = $this->requirePermission('chat.view')) {
            return $denied;
        }

        try {
            $search = (string) ($this->request->getGet('q') ?? '');
            $status = strtolower(trim((string) ($this->request->getGet('status') ?? 'open')));
            $filter = strtolower(trim((string) ($this->request->getGet('filter') ?? '')));
            $channel = strtolower(trim((string) ($this->request->getGet('channel') ?? 'all')));
            if (! in_array($channel, ['all', 'whatsapp', 'instagram', 'messenger'], true)) {
                $channel = 'all';
            }
            $unreadOnly = (int) ($this->request->getGet('unread_only') ?? 0) === 1;
            $assignedToRaw = $this->request->getGet('assigned_to');
            $assignedTo = null;
            if ($assignedToRaw !== null && $assignedToRaw !== '') {
                if ((string) $assignedToRaw === 'unassigned') {
                    $assignedTo = 'unassigned';
                } else {
                    $assignedTo = (int) $assignedToRaw;
                }
            }
            $limit  = max(1, min(100, (int) ($this->request->getGet('limit') ?? 50)));
            $offset = max(0, (int) ($this->request->getGet('offset') ?? 0));

            $db = db_connect();
            $hasConvChannel    = $db->fieldExists('channel', 'conversations');
            $hasContactChannel = $db->fieldExists('channel', 'contacts');
            $hasExternalId     = $db->fieldExists('external_id', 'contacts');
            $hasDeletedAt      = $db->fieldExists('deleted_at', 'contacts');
            $hasFrt            = $db->fieldExists('frt_due_at', 'conversations');
            $hasCtwa           = $db->fieldExists('ctwa_referral', 'conversations');
            $hasIntervened     = $db->fieldExists('intervened_at', 'conversations');

            $select = 'cv.*, c.name AS contact_name, c.mobile, c.last_reply_at,
                       c.last_message_at AS contact_last_message_at,
                       m.content AS last_message_content, m.direction AS last_message_direction,
                       m.message_type AS last_message_type';
            if ($hasContactChannel) {
                $select .= ', c.channel AS contact_channel';
            }
            if ($hasExternalId) {
                $select .= ', c.external_id';
            }

            $builder = $db->table('conversations cv')
                ->select($select)
                ->join('contacts c', 'c.id = cv.contact_id')
                ->join('messages m', 'm.id = cv.last_message_id', 'left');

            if ($hasDeletedAt) {
                $builder->where('c.deleted_at', null);
            }

            // Composite filters (active/expired/ctwa/frt) take precedence over plain status when provided.
            $composite = in_array($filter, \App\Libraries\InboxStatus::COMPOSITE_FILTERS, true)
                ? $filter
                : (in_array($status, \App\Libraries\InboxStatus::COMPOSITE_FILTERS, true) ? $status : '');

            if ($composite !== '' && $composite !== 'all' && $composite !== 'unread') {
                \App\Libraries\InboxStatus::applyCompositeFilter($builder, $composite, $hasFrt, $hasCtwa);
                if (! in_array($composite, ['unassigned', 'assigned'], true)) {
                    // Keep resolved/open etc. when also requested via status (except when status itself is composite).
                    if ($status !== '' && $status !== 'all' && ! in_array($status, \App\Libraries\InboxStatus::COMPOSITE_FILTERS, true)) {
                        \App\Libraries\InboxStatus::applyStatusFilter($builder, $status);
                    }
                }
            } else {
                \App\Libraries\InboxStatus::applyStatusFilter($builder, $status);
            }

            if ($channel !== 'all') {
                if ($hasConvChannel) {
                    $builder->where('cv.channel', $channel);
                } elseif ($hasContactChannel) {
                    $builder->where('c.channel', $channel);
                }
            }
            if ($unreadOnly || $composite === 'unread') {
                $builder->where('cv.unread_count >', 0);
            }
            if ($assignedTo === 'unassigned' || $composite === 'unassigned') {
                $builder->where('cv.assigned_to', null);
            } elseif (is_int($assignedTo) && $assignedTo > 0) {
                $builder->where('cv.assigned_to', $assignedTo);
            }
            $contactFilter = ContactListFilter::fromInput([
                'tag_id'     => $this->request->getGet('tag_id'),
                'attr_key'   => $this->request->getGet('attr_key'),
                'attr_op'    => $this->request->getGet('attr_op'),
                'attr_value' => $this->request->getGet('attr_value'),
            ]);
            if ($contactFilter['tag_id'] > 0) {
                ContactListFilter::applyTag($builder, $contactFilter['tag_id'], 'c.id');
            }
            if ($contactFilter['attr_key'] !== '') {
                ContactListFilter::applyAttribute($builder, $contactFilter['attr_key'], $contactFilter['attr_op'], $contactFilter['attr_value']);
            }

            if ($search !== '') {
                $builder->groupStart()
                    ->like('c.name', $search)
                    ->orLike('c.mobile', $search);
                if ($hasExternalId) {
                    $builder->orLike('c.external_id', $search);
                }
                $builder->groupEnd();
            }

            $rows = $builder
                ->orderBy('cv.last_message_at', 'DESC')
                ->limit($limit, $offset)
                ->get()
                ->getResultArray();

            $normalized = [];
            $nowTs = time();
            foreach ($rows as $row) {
                $rowChannel = (string) ($row['channel'] ?? $row['contact_channel'] ?? 'whatsapp');
                $rawStatus  = (string) ($row['status'] ?? 'open');
                $status     = \App\Libraries\InboxStatus::normalize($rawStatus);
                $within24h  = contact_within_24h_window([
                    'id'            => (int) ($row['contact_id'] ?? 0),
                    'last_reply_at' => $row['last_reply_at'] ?? null,
                ], false);
                $frtDue     = $hasFrt ? ($row['frt_due_at'] ?? null) : null;
                $frtExceeded = false;
                if ($frtDue !== null && $frtDue !== '') {
                    $frtExceeded = strtotime((string) $frtDue) < $nowTs
                        && in_array($status, [\App\Libraries\InboxStatus::OPEN, \App\Libraries\InboxStatus::PENDING], true);
                }
                $ctwa = $hasCtwa ? trim((string) ($row['ctwa_referral'] ?? '')) : '';
                $normalized[] = [
                    'id'              => (int) ($row['id'] ?? 0),
                    'contact_id'      => (int) ($row['contact_id'] ?? 0),
                    'channel'         => $rowChannel,
                    'name'            => (string) ($row['contact_name'] ?? ''),
                    'contact_name'    => (string) ($row['contact_name'] ?? ''),
                    'mobile'          => (string) ($row['mobile'] ?? $row['external_id'] ?? ''),
                    'external_id'     => (string) ($row['external_id'] ?? ''),
                    'status'          => $status,
                    'status_label'    => \App\Libraries\InboxStatus::label($status),
                    'assigned_to'     => isset($row['assigned_to']) && $row['assigned_to'] !== null && $row['assigned_to'] !== ''
                        ? (int) $row['assigned_to']
                        : null,
                    'unread_count'    => (int) ($row['unread_count'] ?? 0),
                    'last_message_at' => $row['last_message_at'] ?? null,
                    'last_message'    => (string) ($row['last_message_content'] ?? ''),
                    'last_message_content' => (string) ($row['last_message_content'] ?? ''),
                    'last_message_direction' => (string) ($row['last_message_direction'] ?? ''),
                    'within_24h'      => $within24h,
                    'window_state'    => $within24h ? 'active' : 'expired',
                    'frt_due_at'      => $frtDue,
                    'frt_exceeded'    => $frtExceeded,
                    'intervened_at'   => $hasIntervened ? ($row['intervened_at'] ?? null) : null,
                    'ctwa_referral'   => $ctwa !== '' ? $ctwa : null,
                    'is_ctwa'         => $ctwa !== '',
                ];
            }

            return $this->jsonResponse(true, $normalized);
        } catch (Throwable $e) {
            log_message('error', 'Chat conversations failed: {msg}', ['msg' => $e->getMessage()]);

            return $this->jsonResponse(false, null, $e->getMessage(), [], 500);
        }
    }

    public function messages(int $contactId): ResponseInterface
    {
        if ($denied = $this->requirePermission('chat.view')) {
            return $denied;
        }

        try {
            $contact = model(ContactModel::class)->find($contactId);
            if ($contact === null) {
                return $this->jsonResponse(false, null, 'Contact not found.', [], 404);
            }

            $channel = strtolower(trim((string) ($contact['channel'] ?? 'whatsapp'))) ?: 'whatsapp';
            $conversation = model(ConversationModel::class)->findOrCreateForContact($contactId, $channel);
            $limit        = max(1, min(200, (int) ($this->request->getGet('limit') ?? 50)));
            $beforeId     = (int) ($this->request->getGet('before_id') ?? 0);
            $afterId      = (int) ($this->request->getGet('after_id') ?? 0);

            // Thread order is by message time so imported history sits before live messages.
            $pivot = $beforeId > 0 ? model(MessageModel::class)->select('id, created_at')->find($beforeId) : null;
            $model = model(MessageModel::class)->where('contact_id', $contactId);
            if ($afterId > 0) {
                $model->where('id >', $afterId);
                $messages = $model->orderBy('id', 'ASC')->findAll($limit);
            } else {
                if (is_array($pivot)) {
                    $model->groupStart()
                        ->where('created_at <', $pivot['created_at'])
                        ->orGroupStart()->where('created_at', $pivot['created_at'])->where('id <', $beforeId)->groupEnd()
                        ->groupEnd();
                }
                $messages = $model->orderBy('created_at', 'DESC')->orderBy('id', 'DESC')->findAll($limit);
                $messages = array_reverse($messages);
            }

            $notes = $afterId > 0
                ? []
                : model(InternalNoteModel::class)->getForContact($contactId);

            $statusUpdates = [];
            if ($afterId > 0) {
                // Silent poll: refresh delivery ticks (External often skips status webhooks)
                $this->refreshCheerioOutboundStatuses($contactId, 10);
                $statusUpdates = model(MessageModel::class)
                    ->select('id, status')
                    ->where('contact_id', $contactId)
                    ->where('direction', 'outbound')
                    ->orderBy('id', 'DESC')
                    ->findAll(40);
            } else {
                // Opening thread — sync a few recent ticks once
                $this->refreshCheerioOutboundStatuses($contactId, 6);
                // Mark conversation read when opening (not on silent poll)
                model(ConversationModel::class)->resetUnread((int) $conversation['id']);
                model(MessageModel::class)
                    ->where('contact_id', $contactId)
                    ->where('direction', 'inbound')
                    ->where('is_read', 0)
                    ->set(['is_read' => 1])
                    ->update();
            }

            return $this->jsonResponse(true, [
                'contact'         => $contact,
                'conversation'    => $conversation,
                'messages'        => $messages,
                'notes'           => $notes,
                'within_24h'      => contact_within_24h_window($contact, true),
                'status_updates'  => $statusUpdates,
            ]);
        } catch (Throwable $e) {
            log_message('error', 'Chat messages failed: {msg}', ['msg' => $e->getMessage()]);

            return $this->jsonResponse(false, null, $e->getMessage(), [], 500);
        }
    }

    public function send(): ResponseInterface
    {
        if ($denied = $this->requirePermission('chat.send')) {
            return $denied;
        }

        $input = $this->requestInput();

        $contactId   = (int) ($input['contact_id'] ?? 0);
        // Accept both UI (`type`/`message`) and API (`message_type`/`content`) contracts.
        $messageType = (string) ($input['message_type'] ?? $input['type'] ?? 'text');
        if ($messageType === 'media') {
            $messageType = 'image'; // refined after file mime detection below
        }
        $content = (string) ($input['content'] ?? $input['text'] ?? $input['message'] ?? '');

        $contact = model(ContactModel::class)->find($contactId);
        if ($contact === null) {
            return $this->jsonResponse(false, null, 'Contact not found.', [], 404);
        }

        $channel = strtolower(trim((string) ($contact['channel'] ?? 'whatsapp'))) ?: 'whatsapp';
        $within24h = contact_within_24h_window($contact, true);

        if ($channel !== 'whatsapp' && $messageType === 'template') {
            return $this->jsonResponse(false, null, 'Templates are only available on WhatsApp.', [], 422);
        }

        if (! $within24h) {
            if ($channel === 'whatsapp' && $messageType !== 'template') {
                return $this->jsonResponse(
                    false,
                    null,
                    'Outside the 24-hour window. Only template messages can be sent.',
                    [],
                    422
                );
            }
            if ($channel !== 'whatsapp') {
                return $this->jsonResponse(
                    false,
                    null,
                    'Outside the 24-hour messaging window for this channel.',
                    [],
                    422
                );
            }
        }

        try {
            $templateName = (string) ($input['template_name'] ?? '');
            $mediaId      = (string) ($input['media_id'] ?? '');
            $mediaUrl     = (string) ($input['media_url'] ?? '');
            $externalId   = null;

            if (in_array($channel, ['instagram', 'messenger'], true)) {
                $pageApi = service('pageMessaging');
                if (! $pageApi->isConfigured()) {
                    return $this->jsonResponse(false, null, 'Page messaging is not configured. Add Page ID + Page Access Token in Settings.', [], 422);
                }
                $settings = service('settingsService');
                if ($channel === 'instagram' && ! $settings->isInstagramInboxEnabled()) {
                    return $this->jsonResponse(false, null, 'Instagram inbox is disabled in Settings.', [], 422);
                }
                if ($channel === 'messenger' && ! $settings->isMessengerInboxEnabled()) {
                    return $this->jsonResponse(false, null, 'Messenger inbox is disabled in Settings.', [], 422);
                }

                $recipientId = trim((string) ($contact['external_id'] ?? ''));
                if ($recipientId === '') {
                    return $this->jsonResponse(false, null, 'Contact has no channel recipient id.', [], 422);
                }

                $file = $this->request->getFile('file') ?? $this->request->getFile('media');
                if ($file !== null && $file->isValid()) {
                    $allowedMimes = [
                        'image/jpeg', 'image/png', 'image/webp', 'image/gif',
                        'application/pdf',
                        'audio/mpeg', 'audio/ogg', 'audio/aac', 'audio/mp4',
                        'video/mp4', 'video/3gpp',
                        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
                        'application/msword',
                        'text/plain', 'text/csv',
                    ];
                    $mime = $file->getMimeType() ?: 'application/octet-stream';
                    if (! in_array($mime, $allowedMimes, true)) {
                        return $this->jsonResponse(false, null, 'File type not allowed: ' . $mime, [], 422);
                    }
                    if ($file->getSize() > 16 * 1024 * 1024) {
                        return $this->jsonResponse(false, null, 'File exceeds 16MB limit.', [], 422);
                    }
                    $dir = WRITEPATH . 'uploads/media/';
                    if (! is_dir($dir)) {
                        mkdir($dir, 0755, true);
                    }
                    $name = $file->getRandomName();
                    $file->move($dir, $name);
                    $mediaUrl = site_url('media/serve/' . $name);
                    if (str_starts_with($mime, 'image/')) {
                        $messageType = 'image';
                    } elseif (str_starts_with($mime, 'video/')) {
                        $messageType = 'video';
                    } elseif (str_starts_with($mime, 'audio/')) {
                        $messageType = 'audio';
                    } else {
                        $messageType = 'file';
                    }
                }

                $attachType = match ($messageType) {
                    'image' => 'image',
                    'video' => 'video',
                    'audio' => 'audio',
                    'file', 'document' => 'file',
                    default => 'text',
                };

                if ($attachType === 'text') {
                    $result = $pageApi->sendText($recipientId, $content, $channel);
                } else {
                    if ($mediaUrl === '') {
                        return $this->jsonResponse(false, null, 'Media URL is required for attachments.', [], 422);
                    }
                    $result = $pageApi->sendAttachment(
                        $recipientId,
                        $attachType,
                        $mediaUrl,
                        $content !== '' ? $content : null
                    );
                    $messageType = $attachType === 'file' ? 'document' : $attachType;
                }

                $externalId = (string) ($result['message_id'] ?? $result['id'] ?? '');
            } else {
                $api = service('whatsApp');
                $to  = $api->normalizePhone((string) ($contact['mobile'] ?? $contact['external_id'] ?? ''));

                $language   = (string) ($input['language'] ?? 'en_US');
                $components = is_array($input['components'] ?? null) ? $input['components'] : [];

                // Meta free-form only works on Meta's number session. External-inbound chats
                // look "open" locally but Meta returns 131047 Re-engagement.
                if ($messageType !== 'template') {
                    $activeProvider = service('settingsService')->getWhatsAppProvider();
                    $lastInboundProvider = model(MessageModel::class)->lastInboundProvider($contactId);
                    if ($activeProvider === 'meta' && $lastInboundProvider === 'cheerio') {
                        $metaPhone = preg_replace(
                            '/\D+/',
                            '',
                            (string) (service('settingsService')->get('meta_display_phone', '') ?: '')
                        ) ?: '';
                        if ($metaPhone === '') {
                            try {
                                $info = $api->getPhoneNumberInfo();
                                $metaPhone = preg_replace('/\D+/', '', (string) ($info['display_phone'] ?? '')) ?: '';
                            } catch (Throwable $ignored) {
                                $metaPhone = '';
                            }
                        }
                        $metaHint = $metaPhone !== '' ? ('+' . $metaPhone) : 'your Meta WhatsApp number';

                        return $this->jsonResponse(
                            false,
                            null,
                            'This chat arrived on the External number, so Meta free-text fails (131047). '
                            . 'Click Template to send a Meta template, or ask the customer to WhatsApp '
                            . $metaHint . ' first.',
                            [],
                            422
                        );
                    }
                }

                if ($messageType === 'template') {
                    $templateId = (int) ($input['template_id'] ?? 0);
                    $tpl        = null;
                    if ($templateId > 0) {
                        $tpl = model(TemplateModel::class)->find($templateId);
                        if ($tpl === null) {
                            return $this->jsonResponse(false, null, 'Template not found.', [], 404);
                        }
                        try {
                            (new \App\Libraries\WhatsAppTemplateSendGuard())->assertApproved($tpl);
                        } catch (\RuntimeException $e) {
                            return $this->jsonResponse(false, null, $e->getMessage(), [], 422);
                        }
                        $templateName = (string) $tpl['name'];
                        $language     = (string) ($tpl['language'] ?? $language);
                    }
                    if ($templateName === '') {
                        return $this->jsonResponse(false, null, 'Template name is required.', [], 422);
                    }
                    if ($tpl === null) {
                        try {
                            (new \App\Libraries\WhatsAppTemplateSendGuard())->assertSendableByName($templateName, $language);
                        } catch (\RuntimeException $e) {
                            return $this->jsonResponse(false, null, $e->getMessage(), [], $e->getCode() === 404 ? 404 : 422);
                        }
                    }
                    if ($components === [] && is_array($input['variables'] ?? null)) {
                        $components = $this->variablesToComponents((array) $input['variables'], $contact);
                    }

                    // IMAGE/VIDEO/DOCUMENT templates need real header media (External/Meta).
                    // Meta approval CDN samples are not reusable at send time.
                    if (is_array($tpl)) {
                        try {
                            $headerComponents = $this->buildTemplateHeaderComponents($tpl, $input);
                        } catch (\InvalidArgumentException $e) {
                            return $this->jsonResponse(false, null, $e->getMessage(), [], 422);
                        }
                        if ($headerComponents !== []) {
                            $components = array_merge($headerComponents, $components);
                        }
                    }
                }

                $file = $this->request->getFile('file') ?? $this->request->getFile('media');
                if ($file !== null && $file->isValid()) {
                    $allowedMimes = [
                        'image/jpeg', 'image/png', 'image/webp', 'image/gif',
                        'application/pdf',
                        'audio/mpeg', 'audio/ogg', 'audio/aac', 'audio/mp4',
                        'video/mp4', 'video/3gpp',
                        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
                        'application/msword',
                        'text/plain', 'text/csv',
                    ];
                    $mime = $file->getMimeType() ?: 'application/octet-stream';
                    if (! in_array($mime, $allowedMimes, true)) {
                        return $this->jsonResponse(false, null, 'File type not allowed: ' . $mime, [], 422);
                    }
                    if ($file->getSize() > 16 * 1024 * 1024) {
                        return $this->jsonResponse(false, null, 'File exceeds 16MB limit.', [], 422);
                    }
                    $dir  = WRITEPATH . 'uploads/media/';
                    if (! is_dir($dir)) {
                        mkdir($dir, 0755, true);
                    }
                    $name = $file->getRandomName();
                    $file->move($dir, $name);
                    $path = $dir . $name;
                    $uploaded = $api->uploadMedia($path, $mime);
                    $mediaId  = (string) ($uploaded['id'] ?? '');
                    $mediaUrl = site_url('media/serve/' . $name);
                    if (str_starts_with($mime, 'image/')) {
                        $messageType = 'image';
                    } elseif (str_starts_with($mime, 'video/')) {
                        $messageType = 'video';
                    } elseif (str_starts_with($mime, 'audio/')) {
                        $messageType = 'audio';
                    } else {
                        $messageType = 'document';
                    }
                    if (! $within24h) {
                        return $this->jsonResponse(false, null, 'Outside the 24-hour window. Only template messages can be sent.', [], 422);
                    }
                }

                if ($messageType === 'template') {
                    $check = service('whatsAppConsent')->eligibility(
                        $contact,
                        \App\Libraries\WhatsAppConsentService::KIND_TEMPLATE,
                        $within24h
                    );
                    if (! $check['ok']) {
                        $message = service('whatsAppConsent')->denialWithConsentRequest($contact, $check);

                        return $this->jsonResponse(false, null, $message, ['policy_reason' => $check['reason']], 422);
                    }
                }

                $result = match ($messageType) {
                    'template' => $api->sendTemplate($to, $templateName, $language, $components),
                    'image' => $api->sendImage(
                        $to,
                        $mediaId !== '' ? $mediaId : $mediaUrl,
                        $content !== '' ? $content : null,
                        $mediaId !== ''
                    ),
                    'document' => $api->sendDocument(
                        $to,
                        $mediaId !== '' ? $mediaId : $mediaUrl,
                        $content !== '' ? $content : null,
                        (string) ($input['filename'] ?? 'document'),
                        $mediaId !== ''
                    ),
                    'audio' => $api->sendAudio(
                        $to,
                        $mediaId !== '' ? $mediaId : $mediaUrl,
                        $mediaId !== ''
                    ),
                    'video' => $api->sendVideo(
                        $to,
                        $mediaId !== '' ? $mediaId : $mediaUrl,
                        $content !== '' ? $content : null,
                        $mediaId !== ''
                    ),
                    default => $api->sendText($to, $content),
                };

                $externalId = (string) ($result['messages'][0]['id'] ?? '');
            }

            $conversation = model(ConversationModel::class)->findOrCreateForContact($contactId, $channel);

            $messageId = model(MessageModel::class)->insert([
                'contact_id'           => $contactId,
                'conversation_id'      => (int) $conversation['id'],
                'channel'              => $channel,
                'direction'            => 'outbound',
                'message_type'         => $messageType,
                'wa_message_id'        => $channel === 'whatsapp' ? ($externalId !== '' ? $externalId : null) : null,
                'wamid'                => $channel === 'whatsapp' ? ($externalId !== '' ? $externalId : null) : null,
                'external_message_id'  => $externalId !== '' ? $externalId : null,
                'content'              => $content !== '' ? $content : ($templateName !== '' ? $templateName : null),
                'media_url'            => $mediaUrl !== '' ? $mediaUrl : null,
                'media_id'             => $mediaId !== '' ? $mediaId : null,
                'payload'              => $result,
                'status'               => 'sent',
                'is_read'              => 1,
            ]);

            model(ConversationModel::class)->update((int) $conversation['id'], [
                'last_message_id' => $messageId,
                'last_message_at' => date('Y-m-d H:i:s'),
                'status'          => 'open',
            ]);

            model(ContactModel::class)->update($contactId, [
                'last_message_at' => date('Y-m-d H:i:s'),
            ]);

            (new ActivityLogger())->log('send', 'chat', 'Outbound message sent', [
                'contact_id' => $contactId,
                'message_id' => $messageId,
                'channel'    => $channel,
            ]);

            $message = model(MessageModel::class)->find((int) $messageId);

            return $this->jsonResponse(true, $message, 'Message sent.');
        } catch (Throwable $e) {
            log_message('error', 'Chat send failed: {msg}', ['msg' => $e->getMessage()]);

            return $this->jsonResponse(false, null, $e->getMessage(), [], 500);
        }
    }

    /**
     * WhatsApp edit: update the same sent text within 15 minutes.
     * After that, the inbox resends it as a new message when the 24h window is open.
     */
    public function edit(int $id): ResponseInterface
    {
        if ($denied = $this->requirePermission('chat.send')) {
            return $denied;
        }

        $input   = $this->requestInput();
        $content = trim((string) ($input['content'] ?? $input['text'] ?? $input['message'] ?? ''));
        if ($content === '') {
            return $this->jsonResponse(false, null, 'Message text is required.', [], 422);
        }

        $message = model(MessageModel::class)->find($id);
        if ($message === null) {
            return $this->jsonResponse(false, null, 'Message not found.', [], 404);
        }

        $channel = strtolower((string) ($message['channel'] ?? 'whatsapp'));
        $type    = strtolower((string) ($message['message_type'] ?? 'text'));
        if (($message['direction'] ?? '') !== 'outbound' || $channel !== 'whatsapp' || ! in_array($type, ['text', ''], true) || ! empty($message['media_url'])) {
            return $this->jsonResponse(false, null, 'Only sent WhatsApp text can be edited.', [], 422);
        }

        if (trim($content) === trim((string) ($message['content'] ?? ''))) {
            return $this->jsonResponse(false, null, 'Change the text before sending.', [], 422);
        }

        $contact = model(ContactModel::class)->find((int) ($message['contact_id'] ?? 0));
        if ($contact === null) {
            return $this->jsonResponse(false, null, 'Contact not found.', [], 404);
        }

        $waId = trim((string) ($message['wa_message_id'] ?: $message['wamid'] ?: $message['external_message_id'] ?: ''));
        $sentAt = strtotime((string) ($message['created_at'] ?? ''));
        $canEditInPlace = $waId !== ''
            && ! str_starts_with($waId, 'import:')
            && $sentAt !== false
            && (time() - $sentAt) <= (15 * 60);

        if ($canEditInPlace) {
            try {
                $api = service('whatsApp');
                $to  = $api->normalizePhone((string) ($contact['mobile'] ?? $contact['external_id'] ?? ''));
                $result = $api->editText($to, $waId, $content);
                $returnedId = trim((string) ($result['messages'][0]['id'] ?? $result['message_id'] ?? $result['id'] ?? ''));
                $replaced = $returnedId !== '' && $returnedId !== $waId;

                if ($replaced) {
                    return $this->storeResentMessage($contact, $content, $returnedId, $result);
                }

                model(MessageModel::class)->update($id, [
                    'content'   => $content,
                    'edited_at' => date('Y-m-d H:i:s'),
                ]);

                log_activity('update', 'chat', 'WhatsApp message edited', [
                    'message_id' => $id,
                    'contact_id' => (int) $contact['id'],
                ]);

                $fresh = model(MessageModel::class)->find($id);

                return $this->jsonResponse(true, [
                    'mode'    => 'edited',
                    'message' => $fresh,
                ], 'Message updated on WhatsApp.');
            } catch (Throwable $e) {
                log_message('error', 'Chat edit failed: {msg}', ['msg' => $e->getMessage()]);

                return $this->jsonResponse(false, null, $e->getMessage(), [], 500);
            }
        }

        if (! contact_within_24h_window($contact, true)) {
            return $this->jsonResponse(
                false,
                null,
                'WhatsApp only lets you edit a message for 15 minutes. The 24-hour window is closed, so it cannot be sent again. Use a template.',
                [],
                422
            );
        }

        try {
            $api = service('whatsApp');
            $to  = $api->normalizePhone((string) ($contact['mobile'] ?? $contact['external_id'] ?? ''));
            $result = $api->sendText($to, $content);
            $externalId = trim((string) ($result['messages'][0]['id'] ?? $result['message_id'] ?? ''));

            return $this->storeResentMessage($contact, $content, $externalId, $result);
        } catch (Throwable $e) {
            log_message('error', 'Chat resend failed: {msg}', ['msg' => $e->getMessage()]);

            return $this->jsonResponse(false, null, $e->getMessage(), [], 500);
        }
    }

    /**
     * @param array<string, mixed> $contact
     * @param array<string, mixed> $result
     */
    protected function storeResentMessage(array $contact, string $content, string $externalId, array $result): ResponseInterface
    {
        $contactId = (int) ($contact['id'] ?? 0);
        $conversation = model(ConversationModel::class)->findOrCreateForContact($contactId, 'whatsapp');
        $messageId = model(MessageModel::class)->insert([
            'contact_id'          => $contactId,
            'conversation_id'     => (int) $conversation['id'],
            'channel'             => 'whatsapp',
            'direction'           => 'outbound',
            'message_type'        => 'text',
            'wa_message_id'       => $externalId !== '' ? $externalId : null,
            'wamid'               => $externalId !== '' ? $externalId : null,
            'external_message_id' => $externalId !== '' ? $externalId : null,
            'content'             => $content,
            'payload'             => $result,
            'status'              => 'sent',
            'is_read'             => 1,
        ]);

        model(ConversationModel::class)->update((int) $conversation['id'], [
            'last_message_id' => $messageId,
            'last_message_at' => date('Y-m-d H:i:s'),
            'status'          => 'open',
        ]);
        model(ContactModel::class)->update($contactId, [
            'last_message_at' => date('Y-m-d H:i:s'),
        ]);

        log_activity('send', 'chat', 'WhatsApp message resent', [
            'contact_id' => $contactId,
            'message_id' => $messageId,
        ]);

        return $this->jsonResponse(true, [
            'mode'    => 'resent',
            'message' => model(MessageModel::class)->find((int) $messageId),
        ], 'Sent again as a new message.');
    }

    public function markRead(): ResponseInterface
    {
        if ($denied = $this->requirePermission('chat.view')) {
            return $denied;
        }

        $input     = $this->requestInput();
        $contactId = (int) ($input['contact_id'] ?? 0);

        if ($contactId <= 0) {
            return $this->jsonResponse(false, null, 'contact_id is required.', [], 422);
        }

        $conversation = model(ConversationModel::class)->findByContact($contactId);
        if ($conversation !== null) {
            model(ConversationModel::class)->resetUnread((int) $conversation['id']);
        }

        model(MessageModel::class)
            ->where('contact_id', $contactId)
            ->where('direction', 'inbound')
            ->where('is_read', 0)
            ->set(['is_read' => 1])
            ->update();

        // Optionally mark last inbound as read via External
        $lastInbound = model(MessageModel::class)
            ->where('contact_id', $contactId)
            ->where('direction', 'inbound')
            ->where('wa_message_id IS NOT NULL', null, false)
            ->orderBy('id', 'DESC')
            ->first();

        if ($lastInbound && ! empty($lastInbound['wa_message_id'])) {
            try {
                service('whatsApp')->markAsRead((string) $lastInbound['wa_message_id']);
            } catch (Throwable $e) {
                log_message('debug', 'markAsRead API skipped: {msg}', ['msg' => $e->getMessage()]);
            }
        }

        // Soft-notification bell / sidebar: clear chat alerts for this contact without refresh
        $uid           = (int) ($this->userId() ?? 0);
        $notifModel    = model(\App\Models\NotificationModel::class);
        $notifCleared  = $uid > 0 ? $notifModel->markChatNotificationsReadForContact($uid, $contactId) : 0;
        $unreadNotifs  = $uid > 0 ? $notifModel->countUnreadForUser($uid) : 0;

        return $this->jsonResponse(true, [
            'contact_id'              => $contactId,
            'notifications_cleared'   => $notifCleared,
            'unread_notifications'    => $unreadNotifs,
        ], 'Marked as read.');
    }

    public function addNote(): ResponseInterface
    {
        if ($denied = $this->requirePermission('chat.view')) {
            return $denied;
        }

        $input     = $this->requestInput();
        $contactId = (int) ($input['contact_id'] ?? 0);
        $note      = trim((string) ($input['note'] ?? ''));

        if ($contactId <= 0 || $note === '') {
            return $this->jsonResponse(false, null, 'contact_id and note are required.', [], 422);
        }

        if (model(ContactModel::class)->find($contactId) === null) {
            return $this->jsonResponse(false, null, 'Contact not found.', [], 404);
        }

        $id = model(InternalNoteModel::class)->insert([
            'contact_id'  => $contactId,
            'user_id'     => $this->userId(),
            'note'        => $note,
            'is_internal' => 1,
        ]);

        if (! $id) {
            return $this->jsonResponse(false, null, 'Failed to save note.', model(InternalNoteModel::class)->errors(), 422);
        }

        $saved = model(InternalNoteModel::class)->find((int) $id);

        return $this->jsonResponse(true, $saved, 'Note added.');
    }

    public function assign(): ResponseInterface
    {
        if ($denied = $this->requirePermission('chat.assign')) {
            return $denied;
        }

        $input       = $this->requestInput();
        $contactId   = (int) ($input['contact_id'] ?? 0);
        $assignedTo  = $input['assigned_to'] ?? null;
        $assignedTo  = $assignedTo === '' || $assignedTo === null ? null : (int) $assignedTo;

        if ($contactId <= 0) {
            return $this->jsonResponse(false, null, 'contact_id is required.', [], 422);
        }

        if (model(ContactModel::class)->find($contactId) === null) {
            return $this->jsonResponse(false, null, 'Contact not found.', [], 404);
        }

        if ($assignedTo !== null) {
            $agent = model(UserModel::class)->find($assignedTo);
            if ($agent === null || ($agent['status'] ?? '') !== 'active') {
                return $this->jsonResponse(false, null, 'Invalid agent.', [], 422);
            }
        }

        model(ContactModel::class)->update($contactId, ['assigned_to' => $assignedTo]);
        $conversation = model(ConversationModel::class)->findOrCreateForContact($contactId);
        model(ConversationModel::class)->update((int) $conversation['id'], ['assigned_to' => $assignedTo]);

        (new ActivityLogger())->log('assign', 'chat', 'Conversation assigned', [
            'contact_id'  => $contactId,
            'assigned_to' => $assignedTo,
        ]);

        return $this->jsonResponse(true, [
            'contact_id'  => $contactId,
            'assigned_to' => $assignedTo,
        ], 'Assigned.');
    }

    public function setStatus(): ResponseInterface
    {
        if ($denied = $this->requirePermission('chat.close')) {
            return $denied;
        }

        $input     = $this->requestInput();
        $contactId = (int) ($input['contact_id'] ?? 0);
        $status    = \App\Libraries\InboxStatus::normalize((string) ($input['status'] ?? ''));
        $channel   = strtolower(trim((string) ($input['channel'] ?? 'whatsapp'))) ?: 'whatsapp';

        if ($contactId <= 0 || ! \App\Libraries\InboxStatus::isWritable($status)) {
            return $this->jsonResponse(
                false,
                null,
                'contact_id and status (open|pending|resolved|chatbot|intervened) are required.',
                [],
                422
            );
        }

        $conversation = model(ConversationModel::class)->findOrCreateForContact($contactId, $channel);
        $payload = ['status' => $status];
        $db = db_connect();
        if ($status === \App\Libraries\InboxStatus::INTERVENED && $db->fieldExists('intervened_at', 'conversations')) {
            $payload['intervened_at'] = date('Y-m-d H:i:s');
        }
        if ($status === \App\Libraries\InboxStatus::OPEN && $db->fieldExists('frt_due_at', 'conversations')) {
            $payload['frt_due_at'] = \App\Libraries\InboxStatus::defaultFrtDueAt();
        }
        model(ConversationModel::class)->update((int) $conversation['id'], $payload);

        (new ActivityLogger())->log('status', 'chat', 'Conversation ' . $status, [
            'contact_id' => $contactId,
            'status'     => $status,
            'channel'    => $channel,
        ]);

        return $this->jsonResponse(true, [
            'contact_id' => $contactId,
            'status'     => $status,
            'status_label' => \App\Libraries\InboxStatus::label($status),
        ], $status === \App\Libraries\InboxStatus::RESOLVED ? 'Conversation resolved.' : 'Conversation updated.');
    }

    public function search(): ResponseInterface
    {
        if ($denied = $this->requirePermission('chat.view')) {
            return $denied;
        }

        $q = (string) ($this->request->getGet('q') ?? '');
        if (strlen($q) < 2) {
            return $this->jsonResponse(true, []);
        }

        $messages = db_connect()->table('messages m')
            ->select('m.id, m.contact_id, m.content, m.created_at, c.name AS contact_name, c.mobile')
            ->join('contacts c', 'c.id = m.contact_id')
            ->like('m.content', $q)
            ->orderBy('m.created_at', 'DESC')
            ->limit(50)
            ->get()
            ->getResultArray();

        $contacts = model(ContactModel::class)->search($q, 20);

        return $this->jsonResponse(true, [
            'messages'  => $messages,
            'contacts'  => $contacts,
        ]);
    }

    /**
     * Build HEADER media component for IMAGE/VIDEO/DOCUMENT templates.
     *
     * Both External and Meta accept Meta-style header components (id or public link).
     * Sample CDN URLs (scontent.whatsapp.net) are not reusable at send time.
     *
     * @param array<string, mixed> $template
     * @param array<string, mixed> $input
     *
     * @return list<array<string, mixed>>
     */
    protected function buildTemplateHeaderComponents(array $template, array $input): array
    {
        $headerType = WhatsAppTemplatePayload::headerTypeFromTemplate($template);
        if ($headerType === '') {
            return [];
        }

        // Already supplied by client as full components.
        $existing = $input['components'] ?? null;
        if (is_array($existing) && WhatsAppTemplatePayload::hasMediaHeader($existing)) {
            return [];
        }

        $mediaId  = trim((string) ($input['header_media_id'] ?? $input['wa_media_id'] ?? ''));
        $mediaUrl = trim((string) ($input['header_media_url'] ?? $input['media_url'] ?? ''));

        $file = $this->request->getFile('header_media')
            ?? $this->request->getFile('header_file');
        if (($mediaId === '' && $mediaUrl === '') && $file !== null && $file->isValid()) {
            $mime = (string) ($file->getMimeType() ?: 'application/octet-stream');
            $allowedHeaderMimes = ['image/jpeg', 'image/png', 'video/mp4', 'video/3gpp', 'application/pdf'];
            if (! in_array($mime, $allowedHeaderMimes, true)) {
                throw new \InvalidArgumentException('Header file type not supported. Upload a JPG/PNG image, MP4 video or PDF document.');
            }
            $dir  = WRITEPATH . 'uploads/media/';
            if (! is_dir($dir)) {
                mkdir($dir, 0755, true);
            }
            $newName = $file->getRandomName();
            $file->move($dir, $newName);
            $fullPath  = $dir . $newName;
            $publicUrl = site_url('media/serve/' . $newName);

            try {
                $uploaded = service('whatsApp')->uploadMedia($fullPath, $mime);
                $mediaId  = trim((string) ($uploaded['id'] ?? $uploaded['media_id'] ?? ''));
            } catch (Throwable $e) {
                log_message('warning', 'Chat template header upload failed: {msg}', ['msg' => $e->getMessage()]);
            }

            model(MediaModel::class)->insert([
                'filename'      => $newName,
                'original_name' => $file->getClientName(),
                'mime_type'     => $mime,
                'size'          => $file->getSize(),
                'path'          => 'uploads/media/' . $newName,
                'wa_media_id'   => $mediaId !== '' ? $mediaId : null,
                'url'           => $publicUrl,
                'uploaded_by'   => $this->userId(),
            ]);

            $mediaUrl = $publicUrl;
        }

        $header = WhatsAppTemplatePayload::buildHeaderComponent($headerType, $mediaId, $mediaUrl);

        return $header !== null ? [$header] : [];
    }

    /**
     * Convert simple variable map to WhatsApp template BODY components.
     *
     * @param array<string, mixed> $variables
     * @param array<string, mixed> $contact
     *
     * @return list<array<string, mixed>>
     */
    protected function variablesToComponents(array $variables, array $contact): array
    {
        if ($variables === []) {
            return [];
        }

        $keys = array_keys($variables);
        usort($keys, static function ($a, $b): int {
            if (is_numeric($a) && is_numeric($b)) {
                return (int) $a <=> (int) $b;
            }

            return strcmp((string) $a, (string) $b);
        });

        $parameters = [];
        foreach ($keys as $key) {
            $raw = trim((string) $variables[$key]);
            if (preg_match('/^\{\{\s*([a-zA-Z0-9_]+)\s*\}\}$/', $raw, $m)) {
                $raw = $m[1];
            }
            $field = strtolower($raw);
            $text  = match ($field) {
                'name' => (string) ($contact['name'] ?? ''),
                'mobile', 'phone' => (string) ($contact['mobile'] ?? ''),
                'email' => (string) ($contact['email'] ?? ''),
                default => $raw,
            };
            $parameters[] = ['type' => 'text', 'text' => $text !== '' ? $text : '-'];
        }

        return [[
            'type'       => 'body',
            'parameters' => $parameters,
        ]];
    }

    /**
     * External often does not push delivered/read webhooks. Poll status API and upgrade ticks.
     * Never downgrades (sent → delivered → read). Meta keeps using webhooks only.
     */
    protected function refreshCheerioOutboundStatuses(int $contactId, int $limit = 8): void
    {
        if (! function_exists('is_cheerio_provider') || ! is_cheerio_provider()) {
            return;
        }

        $rows = model(MessageModel::class)
            ->where('contact_id', $contactId)
            ->where('direction', 'outbound')
            ->whereIn('status', ['sent', 'delivered', 'queued', 'pending'])
            ->groupStart()
                ->where('wamid !=', '')
                ->orWhere('wa_message_id !=', '')
            ->groupEnd()
            ->orderBy('id', 'DESC')
            ->findAll(max(1, min(20, $limit)));

        if ($rows === []) {
            return;
        }

        $rank = [
            'queued'    => 0,
            'pending'   => 0,
            'sent'      => 1,
            'delivered' => 2,
            'read'      => 3,
            'failed'    => 4,
        ];

        $api = new CheerioDirectAPI();

        try {
            foreach ($rows as $row) {
                $wamid = (string) ($row['wamid'] ?? $row['wa_message_id'] ?? '');
                if ($wamid === '') {
                    continue;
                }

                // Skip Meta-era outbound rows — External status API 404s on foreign wamids.
                $payload = $row['payload'] ?? null;
                if (is_string($payload)) {
                    $decoded = json_decode($payload, true);
                    $payload = is_array($decoded) ? $decoded : null;
                }
                if (is_array($payload) && ! array_key_exists('flag', $payload) && empty($payload['provider'])) {
                    // Meta Cloud send payloads are flat (contacts/messages only).
                    continue;
                }

                try {
                    if (! method_exists($api, 'resolveDeliveryStatus')) {
                        break;
                    }
                    $newStatus = $api->resolveDeliveryStatus($wamid);
                } catch (Throwable $e) {
                    log_message('debug', 'External status poll failed for {id}: {msg}', [
                        'id'  => $row['id'] ?? 0,
                        'msg' => $e->getMessage(),
                    ]);
                    continue;
                }

                if ($newStatus === null) {
                    continue;
                }

                $old = strtolower((string) ($row['status'] ?? 'sent'));
                $oldRank = $rank[$old] ?? 0;
                $newRank = $rank[$newStatus] ?? 0;

                // Only upgrade ticks (sent → delivered → read). Never apply External "failed"
                // from status poll when the message was already accepted (false failedAt races).
                // Real delivery failures still arrive via webhook with error details.
                if ($newStatus === 'failed') {
                    continue;
                }
                if ($newRank <= $oldRank) {
                    continue;
                }

                model(MessageModel::class)->update((int) $row['id'], ['status' => $newStatus]);
            }
        } catch (Throwable $e) {
            log_message('debug', 'External status poll aborted: {msg}', ['msg' => $e->getMessage()]);
        }
    }

    /**
     * AI Copilot: Generate quick reply suggestions for Live Chat.
     */
    public function aiSuggest(): ResponseInterface
    {
        if ($denied = $this->requirePermission('chat.view')) {
            return $denied;
        }

        $contactId = (int) ($this->request->getPost('contact_id') ?? 0);
        $userMessage = trim((string) ($this->request->getPost('message') ?? ''));

        if ($contactId <= 0) {
            return $this->jsonResponse(false, null, 'Contact ID is required', [], 400);
        }

        $aiService = service('aiService');
        if (! $aiService->isConfigured()) {
            return $this->jsonResponse(false, null, 'AI assistant is not configured or disabled in Settings.', [], 422);
        }

        $messages = model(MessageModel::class)
            ->where('contact_id', $contactId)
            ->orderBy('id', 'DESC')
            ->findAll(6);
        $messages = array_reverse($messages);

        if ($userMessage === '' && ! empty($messages)) {
            for ($i = count($messages) - 1; $i >= 0; $i--) {
                if (($messages[$i]['direction'] ?? '') === 'inbound') {
                    $userMessage = (string) ($messages[$i]['content'] ?? '');
                    break;
                }
            }
        }

        $suggestions = $aiService->suggestReplies($userMessage, $messages);

        return $this->jsonResponse(true, ['suggestions' => $suggestions]);
    }

    /**
     * AI Copilot: Generate brief conversation summary for agents.
     */
    public function aiSummary(): ResponseInterface
    {
        if ($denied = $this->requirePermission('chat.view')) {
            return $denied;
        }

        $contactId = (int) ($this->request->getPost('contact_id') ?? 0);
        if ($contactId <= 0) {
            return $this->jsonResponse(false, null, 'Contact ID is required', [], 400);
        }

        $aiService = service('aiService');
        if (! $aiService->isConfigured()) {
            return $this->jsonResponse(false, null, 'AI assistant is not configured or disabled in Settings.', [], 422);
        }

        $messages = model(MessageModel::class)
            ->where('contact_id', $contactId)
            ->orderBy('id', 'DESC')
            ->findAll(20);
        $messages = array_reverse($messages);

        $summary = $aiService->summarizeChat($messages);

        return $this->jsonResponse(true, ['summary' => $summary]);
    }
}
